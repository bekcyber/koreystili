import { HangulLetter, BatchimRule } from '../types';

export const HANGUL_VOWELS: HangulLetter[] = [
  {
    id: 'v1',
    char: 'ㅏ',
    name: 'A',
    type: 'basic_vowel',
    uzbekSound: 'A (ochiq A tovushi)',
    romanization: 'a',
    description: 'Vertikal chiziq va o\'ngga kichik gorizontal chiziqcha. Og\'iz ochiq holda "A" deb aytiladi.',
    exampleWord: '아이',
    examplePronunciation: 'ai',
    exampleTranslation: 'Bola / Chaqaloq'
  },
  {
    id: 'v2',
    char: 'ㅑ',
    name: 'YA',
    type: 'basic_vowel',
    uzbekSound: 'Ya',
    romanization: 'ya',
    description: 'Ikkita o\'ngga chiziqcha "Y" qo\'shilishini bildiradi. O\'zbek tilidagi "Ya" tovushi.',
    exampleWord: '야구',
    examplePronunciation: 'yagu',
    exampleTranslation: 'Beysbol'
  },
  {
    id: 'v3',
    char: 'ㅓ',
    name: 'EO',
    type: 'basic_vowel',
    uzbekSound: 'O (keng, ochiq O)',
    romanization: 'eo',
    description: 'Chiziqcha chapga qaragan. Og\'izni kengroq ochib aytiladigan "O" tovushi.',
    exampleWord: '어머니',
    examplePronunciation: 'eomeoni',
    exampleTranslation: 'Ona'
  },
  {
    id: 'v4',
    char: 'ㅕ',
    name: 'YEO',
    type: 'basic_vowel',
    uzbekSound: 'Yo (ochiq Yo)',
    romanization: 'yeo',
    description: 'Chapga 2 ta chiziqcha. "Yo" kabi talaffuz qilinadi.',
    exampleWord: '여자',
    examplePronunciation: 'yeoja',
    exampleTranslation: 'Ayol kishi'
  },
  {
    id: 'v5',
    char: 'ㅗ',
    name: 'O',
    type: 'basic_vowel',
    uzbekSound: 'O\' (lablangan, yopiq O\')',
    romanization: 'o',
    description: 'Gorizontal chiziq va tepaga chiziqcha. Lablar doirachaga aylanadi.',
    exampleWord: '오이',
    examplePronunciation: 'oi',
    exampleTranslation: 'Bodring'
  },
  {
    id: 'v6',
    char: 'ㅛ',
    name: 'YO',
    type: 'basic_vowel',
    uzbekSound: 'Yo\' (lablangan Yo\')',
    romanization: 'yo',
    description: 'Tepaga 2 ta chiziqcha. Lablangan yumaloq "Yo\'".',
    exampleWord: '요리',
    examplePronunciation: 'yori',
    exampleTranslation: 'Pazandachilik / Taom'
  },
  {
    id: 'v7',
    char: 'ㅜ',
    name: 'U',
    type: 'basic_vowel',
    uzbekSound: 'U (toza U)',
    romanization: 'u',
    description: 'Gorizontal chiziq va pastga chiziqcha. O\'zbek tilidagi "U" tovushidek.',
    exampleWord: '우유',
    examplePronunciation: 'uyu',
    exampleTranslation: 'Sut'
  },
  {
    id: 'v8',
    char: 'ㅠ',
    name: 'YU',
    type: 'basic_vowel',
    uzbekSound: 'Yu',
    romanization: 'yu',
    description: 'Pastga 2 ta chiziqcha. O\'zbek tilidagi "Yu" kabi.',
    exampleWord: '유리',
    examplePronunciation: 'yuri',
    exampleTranslation: 'Oyna / Shisha'
  },
  {
    id: 'v9',
    char: 'ㅡ',
    name: 'EU',
    type: 'basic_vowel',
    uzbekSound: 'I (tishlar orasidan chiqadigan chuqur I)',
    romanization: 'eu',
    description: 'Gorizontal tekis chiziq. Tishlarni jilmaygandek bir-biriga yaqinlashtirib aytiladi.',
    exampleWord: '음식',
    examplePronunciation: 'eumsik',
    exampleTranslation: 'Taom / Ovqat'
  },
  {
    id: 'v10',
    char: 'ㅣ',
    name: 'I',
    type: 'basic_vowel',
    uzbekSound: 'I',
    romanization: 'i',
    description: 'Vertikal bitta chiziq. Oddiy "I" tovushi.',
    exampleWord: '이름',
    examplePronunciation: 'ireum',
    exampleTranslation: 'Ism'
  },
  {
    id: 'v11',
    char: 'ㅐ',
    name: 'AE',
    type: 'complex_vowel',
    uzbekSound: 'E (kengroq E)',
    romanization: 'ae',
    description: 'ㅏ va ㅣ birikmasi. O\'zbek tilidagi "E" tovushiga juda yaqin.',
    exampleWord: '배',
    examplePronunciation: 'bae',
    exampleTranslation: 'Qorin / Nok / Kema'
  },
  {
    id: 'v12',
    char: 'ㅔ',
    name: 'E',
    type: 'complex_vowel',
    uzbekSound: 'E (aniq E)',
    romanization: 'e',
    description: 'ㅓ va ㅣ birikmasi. Bugungi kunda ㅐ va ㅔ deyarli bir xil E kabi aytiladi.',
    exampleWord: '가게',
    examplePronunciation: 'gage',
    exampleTranslation: 'Do\'kon'
  },
  {
    id: 'v13',
    char: 'ㅘ',
    name: 'WA',
    type: 'complex_vowel',
    uzbekSound: 'Va (Ua)',
    romanization: 'wa',
    description: 'ㅗ + ㅏ birikmasi. Tezlikda "Va" yoki "Ua" deb aytiladi.',
    exampleWord: '화요일',
    examplePronunciation: 'hwayoil',
    exampleTranslation: 'Seshanba'
  },
  {
    id: 'v14',
    char: 'ㅝ',
    name: 'WEO',
    type: 'complex_vowel',
    uzbekSound: 'Vo (Uo)',
    romanization: 'weo',
    description: 'ㅜ + ㅓ birikmasi. "Vo" kabi eshitiladi.',
    exampleWord: '월요일',
    examplePronunciation: 'woryoil',
    exampleTranslation: 'Dushanba'
  },
  {
    id: 'v15',
    char: 'ㅢ',
    name: 'UI',
    type: 'complex_vowel',
    uzbekSound: 'Iy / E (egalik qo\'shimchasi bo\'lsa)',
    romanization: 'ui',
    description: 'ㅡ + ㅣ birikmasi. So\'z boshida "Iy", egalikda esa "E" deb o\'qiladi.',
    exampleWord: '의사',
    examplePronunciation: 'uisa',
    exampleTranslation: 'Shifokor'
  }
];

export const HANGUL_CONSONANTS: HangulLetter[] = [
  {
    id: 'c1',
    char: 'ㄱ',
    name: 'Giyok (기역)',
    type: 'basic_consonant',
    uzbekSound: 'G / K (boshida K, unlilar orasida G)',
    romanization: 'g / k',
    description: 'So\'z boshida jarangli K kabi, ikki unli o\'rtasida yumshoq G kabi o\'qiladi.',
    exampleWord: '고기',
    examplePronunciation: 'gogi',
    exampleTranslation: 'Go\'sht'
  },
  {
    id: 'c2',
    char: 'ㄴ',
    name: 'Niun (니은)',
    type: 'basic_consonant',
    uzbekSound: 'N',
    romanization: 'n',
    description: 'Har doim "N" tovushini beradi. Til uchi yuqori tishlarga tegadi.',
    exampleWord: '나라',
    examplePronunciation: 'nara',
    exampleTranslation: 'Mamlakat / Davlat'
  },
  {
    id: 'c3',
    char: 'ㄷ',
    name: 'Digeut (디귿)',
    type: 'basic_consonant',
    uzbekSound: 'D / T (boshida T, unlilar orasida D)',
    romanization: 'd / t',
    description: 'So\'z boshida T ga yaqin, unlilar orasida D deb o\'qiladi.',
    exampleWord: '다리',
    examplePronunciation: 'dari',
    exampleTranslation: 'Oyoq / Ko\'prik'
  },
  {
    id: 'c4',
    char: 'ㄹ',
    name: 'Rieul (리을)',
    type: 'basic_consonant',
    uzbekSound: 'R / L (unlilar orasida R, bo\'g\'in oxirida L)',
    romanization: 'r / l',
    description: 'Unlilar orasida "R", bo\'g\'in oxirida (batchim) "L" deb aytiladi.',
    exampleWord: '라면',
    examplePronunciation: 'ramyeon',
    exampleTranslation: 'Ramyon (sho\'rva/lapsha)'
  },
  {
    id: 'c5',
    char: 'ㅁ',
    name: 'Mium (미음)',
    type: 'basic_consonant',
    uzbekSound: 'M',
    romanization: 'm',
    description: 'Har doim "M" tovushini beradi. Kvadrat shaklida yoziladi.',
    exampleWord: '물',
    examplePronunciation: 'mul',
    exampleTranslation: 'Suv'
  },
  {
    id: 'c6',
    char: 'ㅂ',
    name: 'Biup (비읍)',
    type: 'basic_consonant',
    uzbekSound: 'B / P (boshida P, unlilar orasida B)',
    romanization: 'b / p',
    description: 'So\'z boshida jarangli P kabi, unlilar orasida B deb aytiladi.',
    exampleWord: '밥',
    examplePronunciation: 'bap',
    exampleTranslation: 'Guruch / Ovqat'
  },
  {
    id: 'c7',
    char: 'ㅅ',
    name: 'Siot (시옷)',
    type: 'basic_consonant',
    uzbekSound: 'S / Sh (i, ya, ye, yo, yu oldida Sh)',
    romanization: 's / sh',
    description: 'Oddiy holatda "S", ammo ㅣ (I) yoki Y-li unlilar oldida "Sh" deb o\'qiladi.',
    exampleWord: '시간',
    examplePronunciation: 'shigan',
    exampleTranslation: 'Vaqt'
  },
  {
    id: 'c8',
    char: 'ㅇ',
    name: 'Ieung (이응)',
    type: 'basic_consonant',
    uzbekSound: 'Tovushsiz / NG (pastda bo\'lsa)',
    romanization: 'ng (or mute)',
    description: 'Bo\'g\'in boshida unli bilan kelganda tovushsiz! Bo\'g\'in ostida (batchim) kelsa "NG" burun tovushi bo\'ladi.',
    exampleWord: '안녕',
    examplePronunciation: 'annyeong',
    exampleTranslation: 'Salom'
  },
  {
    id: 'c9',
    char: 'ㅈ',
    name: 'Jieut (지읒)',
    type: 'basic_consonant',
    uzbekSound: 'J / Ch (boshida Ch, unlilar orasida J)',
    romanization: 'j / ch',
    description: 'So\'z boshida Ch ga yaqin, unlilar orasida yumshoq J deb o\'qiladi.',
    exampleWord: '집',
    examplePronunciation: 'jip',
    exampleTranslation: 'Uy'
  },
  {
    id: 'c10',
    char: 'ㅊ',
    name: 'Chieut (치읓)',
    type: 'basic_consonant',
    uzbekSound: 'CH (kuchli, havoli)',
    romanization: 'ch',
    description: 'Tepasida chiziqcha bor. Kuchli "Ch" deb talaffuz qilinadi.',
    exampleWord: '친구',
    examplePronunciation: 'chingu',
    exampleTranslation: 'Do\'st'
  },
  {
    id: 'c11',
    char: 'ㅋ',
    name: 'Kieuk (키읔)',
    type: 'basic_consonant',
    uzbekSound: 'K (havoli, kuchli)',
    romanization: 'k',
    description: 'Tomoqdan havo chiqarib aytiladigan kuchli "K" tovushi.',
    exampleWord: '커피',
    examplePronunciation: 'keopi',
    exampleTranslation: 'Kofe'
  },
  {
    id: 'c12',
    char: 'ㅌ',
    name: 'Tieut (티읕)',
    type: 'basic_consonant',
    uzbekSound: 'T (havoli, kuchli)',
    romanization: 't',
    description: 'Kuchli havo bilan aytiladigan "T" tovushi.',
    exampleWord: '택시',
    examplePronunciation: 'taeksi',
    exampleTranslation: 'Taksi'
  },
  {
    id: 'c13',
    char: 'ㅍ',
    name: 'Pieup (피읖)',
    type: 'basic_consonant',
    uzbekSound: 'P (havoli, kuchli)',
    romanization: 'p',
    description: 'Kuchli havo bilan aytiladigan "P" tovushi.',
    exampleWord: '포도',
    examplePronunciation: 'podo',
    exampleTranslation: 'Uzum'
  },
  {
    id: 'c14',
    char: 'ㅎ',
    name: 'Hieut (히읗)',
    type: 'basic_consonant',
    uzbekSound: 'H',
    romanization: 'h',
    description: 'O\'zbek tilidagi "H" tovushiga teng.',
    exampleWord: '한국',
    examplePronunciation: 'hanguk',
    exampleTranslation: 'Janubiy Koreya'
  },
  {
    id: 'c15',
    char: 'ㄲ',
    name: 'Ssang-giyok (쌍기역)',
    type: 'double_consonant',
    uzbekSound: 'Qattiq Kk',
    romanization: 'kk',
    description: 'Hech qanday havosiz, qisilgan tomoq bilan qattiq "Kk" deb aytiladi.',
    exampleWord: '꽃',
    examplePronunciation: 'kkot',
    exampleTranslation: 'Gul'
  },
  {
    id: 'c16',
    char: 'ㄸ',
    name: 'Ssang-digeut (쌍디귿)',
    type: 'double_consonant',
    uzbekSound: 'Qattiq Tt',
    romanization: 'tt',
    description: 'Qattiq, tarang "Tt" tovushi.',
    exampleWord: '떡볶이',
    examplePronunciation: 'tteokbokki',
    exampleTranslation: 'Tteokbokki (guruch kulchalari)'
  },
  {
    id: 'c17',
    char: 'ㅃ',
    name: 'Ssang-biup (쌍비읍)',
    type: 'double_consonant',
    uzbekSound: 'Qattiq Pp',
    romanization: 'pp',
    description: 'Lablarni qattiq qisib aytiladigan "Pp" tovushi.',
    exampleWord: '빵',
    examplePronunciation: 'ppang',
    exampleTranslation: 'Non'
  },
  {
    id: 'c18',
    char: 'ㅆ',
    name: 'Ssang-siot (쌍시옷)',
    type: 'double_consonant',
    uzbekSound: 'Qattiq Ss',
    romanization: 'ss',
    description: 'Kuchli, tarang "Ss" tovushi.',
    exampleWord: '싸다',
    examplePronunciation: 'ssada',
    exampleTranslation: 'Arzon bo\'lmoq'
  },
  {
    id: 'c19',
    char: 'ㅉ',
    name: 'Ssang-jieut (쌍지읒)',
    type: 'double_consonant',
    uzbekSound: 'Qattiq Jj / Chch',
    romanization: 'jj',
    description: 'Kuchli, tarang "Jj" tovushi.',
    exampleWord: '짜다',
    examplePronunciation: 'jjada',
    exampleTranslation: 'Sho\'r bo\'lmoq'
  }
];

export const BATCHIM_RULES: BatchimRule[] = [
  {
    representativeSound: '[ㄱ] (K)',
    letters: ['ㄱ', 'ㅋ', 'ㄲ', 'ㄳ', 'ㄺ'],
    uzbekExplanation: 'Bo\'g\'in oxirida kelganda nafas to\'xtatilib "K" tovushi eshitiladi.',
    examples: [
      { word: '책', reading: '[chaek]', meaning: 'Kitob' },
      { word: '부엌', reading: '[bueok]', meaning: 'Oshxona' },
      { word: '밖', reading: '[bak]', meaning: 'Tashqari' }
    ]
  },
  {
    representativeSound: '[ㄴ] (N)',
    letters: ['ㄴ', 'ㄵ', 'ㄶ'],
    uzbekExplanation: 'Har doim toza "N" tovushini beradi.',
    examples: [
      { word: '눈', reading: '[nun]', meaning: 'Ko\'z / Qor' },
      { word: '문', reading: '[mun]', meaning: 'Eshik' }
    ]
  },
  {
    representativeSound: '[ㄷ] (T)',
    letters: ['ㄷ', 'ㅅ', 'ㅈ', 'ㅊ', 'ㅌ', 'ㅎ', 'ㅆ'],
    uzbekExplanation: 'Eng ko\'p uchraydigan qoida: bu harflarning barchasi bo\'g\'in oxirida to\'xtatilgan "T" kabi o\'qiladi!',
    examples: [
      { word: '옷', reading: '[ot]', meaning: 'Kiyim (ㅅ harfi T ga aylanadi)' },
      { word: '꽃', reading: '[kkot]', meaning: 'Gul (ㅊ harfi T ga aylanadi)' },
      { word: '낮', reading: '[nat]', meaning: 'Kunduz (ㅈ harfi T ga aylanadi)' }
    ]
  },
  {
    representativeSound: '[ㄹ] (L)',
    letters: ['ㄹ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㅀ'],
    uzbekExplanation: 'Bo\'g\'in oxirida yumshoq "L" deb talaffuz qilinadi.',
    examples: [
      { word: '물', reading: '[mul]', meaning: 'Suv' },
      { word: '말', reading: '[mal]', meaning: 'Gap / Ot (hayvon)' },
      { word: '달', reading: '[dal]', meaning: 'Oy (osmondagi)' }
    ]
  },
  {
    representativeSound: '[ㅁ] (M)',
    letters: ['ㅁ', 'ㄻ'],
    uzbekExplanation: 'Har doim "M" deb o\'qiladi.',
    examples: [
      { word: '엄마', reading: '[eomma]', meaning: 'Ona / Oyi' },
      { word: '마음', reading: '[maum]', meaning: 'Ko\'ngil' }
    ]
  },
  {
    representativeSound: '[ㅂ] (P)',
    letters: ['ㅂ', 'ㅍ', 'ㅄ', 'ㄿ'],
    uzbekExplanation: 'Lablar yopilib, havoni to\'xtatib "P" deb o\'qiladi.',
    examples: [
      { word: '집', reading: '[jip]', meaning: 'Uy' },
      { word: '잎', reading: '[ip]', meaning: 'Barg (ㅍ harfi P ga aylanadi)' }
    ]
  },
  {
    representativeSound: '[ㅇ] (NG)',
    letters: ['ㅇ'],
    uzbekExplanation: 'Bo\'g\'in ostida kelsa o\'zbek tilidagi burun "NG" tovushini beradi.',
    examples: [
      { word: '강', reading: '[gang]', meaning: 'Daryo' },
      { word: '공', reading: '[gong]', meaning: 'Koptok' },
      { word: '사랑', reading: '[sarang]', meaning: 'Sevgi' }
    ]
  }
];
