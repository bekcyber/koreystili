import { QuizQuestion } from '../types';

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    type: 'hangul',
    prompt: 'Koreys alifbosida "ㄱ" undoshi va "ㅏ" unlisi birlashganda qaysi harf/bo\'g\'in hosil bo\'ladi?',
    koreanText: 'ㄱ + ㅏ = ?',
    options: ['가 (Ga/Ka)', '고 (Go)', '구 (Gu)', '기 (Gi)'],
    correctAnswer: 0,
    explanation: 'ㄱ (G/K) va vertikal ㅏ (A) unlisi birlashib "가" (ga) bo\'g\'inini hosil qiladi.'
  },
  {
    id: 2,
    type: 'meaning',
    prompt: '"안녕하세요" (Annyeonghaseyo) iborasi o\'zbek tilida qanday ma\'noni anglatadi?',
    koreanText: '안녕하세요',
    options: ['Xayr, yaxshi qoling', 'Assalomu alaykum / Salom', 'Rahmat', 'Kechirasiz'],
    correctAnswer: 1,
    explanation: '안녕하세요 - eng asosiy, kundalik rasmiy-hurmat salomlashish shaklidir.'
  },
  {
    id: 3,
    type: 'listening',
    prompt: 'Tinglang va to\'g\'ri so\'zni tanlang: Quyidagi so\'z "Suv" ma\'nosini bildiradi:',
    koreanText: '물',
    options: ['물 (Mul - Suv)', '불 (Bul - Olov)', '달 (Dal - Oy)', '발 (Bal - Oyoq)'],
    correctAnswer: 0,
    explanation: '물 (mul) - koreys tilida suv demakdir. Pastdagi ㄹ harfi L tovushini beradi.'
  },
  {
    id: 4,
    type: 'grammar',
    prompt: 'Bo\'sh o\'ringa to\'g\'ri qo\'shimchani tanlang: "저는 학생___" (Men talabaman)',
    koreanText: '저는 학생___ (talaba so\'zi undosh bilan tugagan)',
    options: ['예요', '이에요', '를', '에서'],
    correctAnswer: 1,
    explanation: 'So\'z undosh harf bilan tugasa (학생 - ng undoshi bilan tugaydi), ~이에요 qo\'shiladi.'
  },
  {
    id: 5,
    type: 'meaning',
    prompt: '"감사합니다" (Gamsahamnida) so\'zining ma\'nosi nima?',
    koreanText: '감사합니다',
    options: ['Kechirasiz', 'Xayr', 'Rahmat / Tashakkur', 'Iltimos'],
    correctAnswer: 2,
    explanation: '감사합니다 - minnatdorchilik bildirishning eng ehtiromli shakli.'
  },
  {
    id: 6,
    type: 'hangul',
    prompt: 'Quyidagi so\'zlardan qaysi birida "Batchim" (pastki undosh) bor?',
    koreanText: '한국, 나무, 비, 바다',
    options: ['나무 (Namu)', '비 (Bi)', '한국 (Hanguk)', '바da (Bada)'],
    correctAnswer: 2,
    explanation: '한국 so\'zida 한 ostida ㄴ, va 국 ostida ㄱ batchimlari mavjud.'
  },
  {
    id: 7,
    type: 'grammar',
    prompt: '"Kutubxonada dars qilyapman" gapida "kutubxonada" so\'ziga qaysi qo\'shimcha qo\'shiladi?',
    koreanText: '도서관___ 공부해요',
    options: ['에 (E)', '에서 (Eseo)', '을 (Eul)', '은 (Eun)'],
    correctAnswer: 1,
    explanation: 'Joyda faoliyat yoki harakat sodir bo\'lganda joy nomiga ~에서 (eseo) qo\'shiladi.'
  },
  {
    id: 8,
    type: 'meaning',
    prompt: 'Do\'konda "Bu olma necha pul?" deb qanday so\'raladi?',
    koreanText: '이 사과 ___ ?',
    options: ['어디예요? (Qayerda?)', '얼마예요? (Necha pul?)', '누구예요? (Kim?)', '언제예요? (Qachon?)'],
    correctAnswer: 1,
    explanation: '얼마예요? (eolmayeyo?) - narx so\'rash uchun asosiy ibora.'
  },
  {
    id: 9,
    type: 'meaning',
    prompt: 'EPS-TOPIK: "안전모" (anjeonmo) so\'zi nimani anglatadi?',
    koreanText: '안전모',
    options: ['Maxsus himoya kaskasi', 'Ishchi kiyim', 'Himoya ko\'zoynagi', 'Payvandlash uskunasi'],
    correctAnswer: 0,
    explanation: '안전 (xavfsizlik) + 모 (bosh kiyimi/shapka) = Himoya kaskasi (kaska).'
  },
  {
    id: 10,
    type: 'listening',
    prompt: '"Ramyon" yoki "Ovqat" yeyishni xohlasangiz qaysi fe\'l ishlatiladi?',
    koreanText: '먹다 (Meokda)',
    options: ['먹다 (Yemoq)', '마시다 (Ichmoq)', '가다 (Bormoq)', '자다 (Uxlamoq)'],
    correctAnswer: 0,
    explanation: '먹다 (meokda) - yemoq fe\'li. Hozirgi zamonda "먹어요" (meogeoyo) bo\'ladi.'
  }
];
