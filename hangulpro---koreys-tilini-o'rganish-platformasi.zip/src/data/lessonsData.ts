import { Lesson } from '../types';

export const LESSONS: Lesson[] = [
  {
    id: 1,
    level: 'Noldan (Level 1)',
    title: 'Hangul: Alifbo va Bo\'g\'in Yig\'ish Qoidalari',
    koreanTitle: '한글 읽기와 발음',
    description: 'Koreys alifbosining tuzilishi, unli va undoshlarning bo\'g\'inga birlashishi, tovush uyg\'unligi va o\'qish texnikasi.',
    estimatedMinutes: 25,
    objectives: [
      'Hangul tarixi va Sejong Qiroli ixtirosi haqida bilish',
      'Undosh + Unli vertikal va gorizontal bloklar tuzilishi',
      'Batchim (pastki undosh) tushunchasini to\'liq o\'zlashtirish',
      'Birinchi koreyscha so\'zlarni mustaqil o\'qiy olish'
    ],
    dialogue: [
      {
        speaker: 'O\'qituvchi',
        korean: '한글은 1443년 세종대왕이 만들었습니다.',
        romanization: 'Hangeureun cheon-sa-baek-sa-ship-sam nyeon Sejongdaewangi mandeureotseumnida.',
        uzbek: 'Hangul 1443-yilda Buyuk Qirol Sejong tomonidan yaratilgan.'
      },
      {
        speaker: 'Talaba',
        korean: '배우기 쉬워요?',
        romanization: 'Baeugi swiwoyo?',
        uzbek: 'O\'rganish osonmi?'
      },
      {
        speaker: 'O\'qituvchi',
        korean: '네, 원리만 알면 하루 만에 읽을 수 있어요!',
        romanization: 'Ne, wonriman almyeon haru mane ilgeul su isseoyo!',
        uzbek: 'Ha, qoidasini bilsangiz, bir kunda o\'qiy olasiz!'
      }
    ],
    grammar: [
      {
        title: 'Bo\'g\'in Bloklari Sxemasi',
        rule: 'Undosh + Unli yoki Undosh + Unli + Undosh',
        explanation: 'Koreys yozuvida harflar yonma-yon qator qilib yozilmaydi, balki kvadrat bloklarga yig\'iladi. Masalan: ㄱ + ㅏ = 가 (ga); ㅎ + ㅏ + ㄴ = 한 (han).',
        examples: [
          { korean: '가방', romanization: 'gabang', uzbek: 'Sumka' },
          { korean: '한국', romanization: 'hanguk', uzbek: 'Koreya' },
          { korean: '사람', romanization: 'saram', uzbek: 'Inson' }
        ]
      },
      {
        title: 'Nol tovushli ㅇ (Ieung)',
        rule: 'So\'z unli tovush bilan boshlansa, oldiga ㅇ qo\'yiladi',
        explanation: 'Koreys tilida hech bir bo\'g\'in yolg\'iz unli bilan yozilmaydi. Unli bo\'g\'in boshida kelsa, oldiga tovushsiz "ㅇ" yoziladi: masalan, "A" harfi yolg\'iz yozilmaydi, balki "아" deb yoziladi.',
        examples: [
          { korean: '아이', romanization: 'ai', uzbek: 'Bola' },
          { korean: '우유', romanization: 'uyu', uzbek: 'Sut' },
          { korean: '오이', romanization: 'oi', uzbek: 'Bodring' }
        ]
      }
    ],
    vocabulary: [
      { korean: '한글', romanization: 'hangeul', uzbek: 'Koreys alifbosi' },
      { korean: '한국어', romanization: 'hangugeo', uzbek: 'Koreys tili' },
      { korean: '선생님', romanization: 'seonsaengnim', uzbek: 'Ustoz / O\'qituvchi' },
      { korean: '학생', romanization: 'haksaeng', uzbek: 'Talaba / O\'quvchi' },
      { korean: '책', romanization: 'chaek', uzbek: 'Kitob' },
      { korean: '공책', romanization: 'gongchaek', uzbek: 'Daftar' }
    ],
    tips: [
      'Vertikal unlilar (ㅏ, ㅑ, ㅓ, ㅕ, ㅣ) undoshning o\'ng tomoniga yoziladi (가, 나, 다).',
      'Gorizontal unlilar (ㅗ, ㅛ, ㅜ, ㅠ, ㅡ) undoshning tagiga yoziladi (고, 노, 도).',
      'Batchim (pastki undosh) har doim eng pastga yoziladi (밥, 집, 달).'
    ]
  },
  {
    id: 2,
    level: 'Boshlang\'ich (Level 1)',
    title: 'Salomlashish, Tanishuv va Hurmat Shakllari',
    koreanTitle: '인사와 자기소개',
    description: 'Kundalik salom-alik, o\'zini tanishtirish, kasbi va millatini aytish, shuningdek rasmiy/norasmiy hurmat uslublari.',
    estimatedMinutes: 30,
    objectives: [
      'To\'g\'ri salomlashish va xayrlashishni o\'rganish',
      'Egalik va mavzu qo\'shimchalari: ~은/는 (Eun/Neun)',
      'Tasdiq qo\'shimchalari: ~이에요/예요 va ~입니다',
      'O\'zbekiston fuqarosi ekanligini ayta olish'
    ],
    dialogue: [
      {
        speaker: 'Minho',
        korean: '안녕하세요! 저는 이민호입니다.',
        romanization: 'Annyeonghaseyo! Jeoneun Lee Min-ho imnida.',
        uzbek: 'Assalomu alaykum! Men Li Minhomon.'
      },
      {
        speaker: 'Anvar',
        korean: '반갑습니다, 민호 씨. 저는 안바르입니다. 우즈베키스탄 사람이에요.',
        romanization: 'Bangapseumnida, Minho ssi. Jeoneun Anbareu imnida. Ujeubekiseutan saram-ieyo.',
        uzbek: 'Tanishganimdan xursandman, Minho. Men Anvarman. O\'zbekistonlikman.'
      },
      {
        speaker: 'Minho',
        korean: '안바르 씨는 학생이에요?',
        romanization: 'Anbareu ssineun haksaeng-ieyo?',
        uzbek: 'Anvar, siz talabamisiz?'
      },
      {
        speaker: 'Anvar',
        korean: '네, 저는 한국 대학교 학생이에요.',
        romanization: 'Ne, jeoneun hanguk daehakgyo haksaeng-ieyo.',
        uzbek: 'Ha, men Koreya universiteti talabasiman.'
      }
    ],
    grammar: [
      {
        title: 'Mavzu qo\'shimchasi: ~은 / 는',
        rule: 'Undosh bilan tugasa: ~은 | Unli bilan tugasa: ~는',
        explanation: 'Gapning asosiy mavzusini yoki egasini bildiradi ("haqida gapiradigan bo\'lsak", "...ga kelsak"). Masalan: 저 (men - unli bilan tugagan) + 는 = 저는 (joneun - menga kelsak, men); 사람 (inson - undosh bilan tugagan) + 은 = 사람은 (sarameun).',
        examples: [
          { korean: '저는 학생이에요.', romanization: 'Jeoneun haksaeng-ieyo.', uzbek: 'Men talabaman.' },
          { korean: '이것은 책이에요.', romanization: 'Igeoseun chaek-ieyo.', uzbek: 'Bu esa kitobdir.' }
        ]
      },
      {
        title: 'Hurmat shaklidagi xabar: ~이에요 / 예요',
        rule: 'Undosh bilan tugasa: ~이에요 | Unli bilan tugasa: ~예요',
        explanation: 'O\'zbek tilidagi "...dir", "...man", "...miz" ma\'nosini beruvchi hozirgi zamon norasmiy-hurmat shakli. Rasmiy shaklda ~입니다 (imnida) ishlatiladi.',
        examples: [
          { korean: '우즈베키스탄 사람이에요.', romanization: 'Ujeubekiseutan saram-ieyo.', uzbek: 'O\'zbekistonlikman.' },
          { korean: '친구예요.', romanization: 'Chingu-yeyo.', uzbek: 'Do\'stimdir.' }
        ]
      }
    ],
    vocabulary: [
      { korean: '안녕하세요', romanization: 'annyeonghaseyo', uzbek: 'Assalomu alaykum / Salom' },
      { korean: '반갑습니다', romanization: 'bangapseumnida', uzbek: 'Tanishganimdan xursandman' },
      { korean: '안녕히 계세요', romanization: 'annyeonghi gyeseyo', uzbek: 'Xayr, yaxshi qoling (ketuvchi aytadi)' },
      { korean: '안녕히 가세요', romanization: 'annyeonghi gaseyo', uzbek: 'Xayr, oq yo\'l (qoluvchi aytadi)' },
      { korean: '감사합니다', romanization: 'gamsahamnida', uzbek: 'Rahmat / Tashakkur' },
      { korean: '죄송합니다', romanization: 'joesonghamnida', uzbek: 'Kechirasiz / Uzr' },
      { korean: '저', romanization: 'jeo', uzbek: 'Men (kamtarlik bilan)' },
      { korean: '이름', romanization: 'ireum', uzbek: 'Ism' }
    ],
    tips: [
      'Koreys madaniyatida yoshi kattaroq yoki yangi tanishgan odamga ozgina egilib ta\'zim qilish hurmat belgisi hisoblanadi.',
      'Birovning ismiga ~씨 (ssi - janob/xonim) qo\'shib murojaat qilinadi: Minho ssi.'
    ]
  },
  {
    id: 3,
    level: 'Boshlang\'ich (Level 1)',
    title: 'Sonlar, Narxlar va Vaqtni Aytish',
    koreanTitle: '숫자와 시간, 가격',
    description: 'Sin-koreys va Sof koreys son tizimlari, pul birligi (Von), soat va yoshni to\'g\'ri ifodalash sirlari.',
    estimatedMinutes: 35,
    objectives: [
      'Sin-koreys sonlari (1-100+) va ulardan pul, sana, telefon raqamlarida foydalanish',
      'Sof koreys sonlari (1-10) va hisoblagich so\'zlar (odam, dona, shisha)',
      'Soat va daqiqani aniq ayta olish',
      'Do\'konda narx so\'rash'
    ],
    dialogue: [
      {
        speaker: 'Mijoz',
        korean: '사장님, 이 사과 얼마예요?',
        romanization: 'Sajangnim, i sagwa eolmayeyo?',
        uzbek: 'Xo\'jayin, bu olma necha pul?'
      },
      {
        speaker: 'Sotuvchi',
        korean: '한 개에 삼천 원이에요.',
        romanization: 'Han gaee samcheon won-ieyo.',
        uzbek: 'Bir donasi 3,000 von.'
      },
      {
        speaker: 'Mijoz',
        korean: '세 개 주세요. 여기 삼만 원 있어요.',
        romanization: 'Se gae juseyo. Yeogi sam-man won isseoyo.',
        uzbek: 'Uch dona bering. Mana 30,000 von.'
      }
    ],
    grammar: [
      {
        title: 'Ikki xil son tizimi qoidasi',
        rule: 'Sin-koreys: Sana, pul, daqiqa | Sof koreys: Soat, yosh, dona hisoblash',
        explanation: 'Koreys tilida 2 xil son bor. Pul (von), telefon, sana, va daqiqa uchun Sin-koreys (일, 이, 삼, 사...). Soatning soat qismi va narsalarni sanash uchun Sof koreys (하나, 둘, 셋, 넷...) ishlatiladi.',
        examples: [
          { korean: '오후 세 시 삼십 분', romanization: 'ohu se si samsip bun', uzbek: 'Kunduzi 3:30 (soat = se, daqiqa = samsip)' },
          { korean: '오천 원', romanization: 'ocheon won', uzbek: '5,000 von' }
        ]
      },
      {
        title: 'Hisoblagich so\'zlar: ~개, ~명, ~병',
        rule: 'Sof son + hisoblagich (hana -> han, dul -> du, set -> se)',
        explanation: 'Dona uchun 개 (gae), odam uchun 명 (myeong), shisha uchun 병 (byeong). Son hisoblagich oldida qisqaradi: 하나 -> 한 개, 둘 -> 두 개, 셋 -> 세 개.',
        examples: [
          { korean: '커피 두 잔', romanization: 'keopi du jan', uzbek: 'Ikki finjon kofe' },
          { korean: '물 한 병', romanization: 'mul han byeong', uzbek: 'Bir shisha suv' }
        ]
      }
    ],
    vocabulary: [
      { korean: '일, 이, 삼, 사, 오', romanization: 'il, i, sam, sa, o', uzbek: '1, 2, 3, 4, 5 (Sin-koreys)' },
      { korean: '육, 칠, 팔, 구, 십', romanization: 'yuk, chil, pal, gu, sip', uzbek: '6, 7, 8, 9, 10 (Sin-koreys)' },
      { korean: '백, 천, 만', romanization: 'baek, cheon, man', uzbek: '100, 1,000, 10,000' },
      { korean: '하나, 둘, 셋, 넷, 다섯', romanization: 'hana, dul, set, net, daseot', uzbek: '1, 2, 3, 4, 5 (Sof koreys)' },
      { korean: '원', romanization: 'won', uzbek: 'Von (Koreya valyutasi ₩)' },
      { korean: '얼마예요?', romanization: 'eolmayeyo?', uzbek: 'Necha pul?' }
    ],
    tips: [
      'Koreyada 10,000 lik birlik (만 - man) asosiy hisoblanadi. 50,000 won = 오만 원 (o-man won).',
      'Do\'konda narsa so\'raganda so\'z oxiriga 주세요 (juseyo - bering) qo\'shiladi.'
    ]
  },
  {
    id: 4,
    level: 'Boshlang\'ich (Level 2)',
    title: 'Harakat Fe\'llari va Hozirgi Zamon: ~아요 / 어요',
    koreanTitle: '동사와 현재 시제',
    description: 'Koreys tilida fe\'llarning o\'zagi, zamon yasash qoidalari, joy qo\'shimchasi ~에서 va narsa qo\'shimchasi ~을/를.',
    estimatedMinutes: 35,
    objectives: [
      'Fe\'l o\'zagidan hozirgi zamon shaklini yasash (~아요/어요)',
      'Harakat joyi qo\'shimchasi: ~에서 (qayerda harakat sodir bo\'lyapti)',
      'Tushum kelishigi: ~을 / 를',
      'Kundalik nima qilayotganini bayon qilish'
    ],
    dialogue: [
      {
        speaker: 'Sora',
        korean: '지금 뭐 해요?',
        romanization: 'Jigeum mwo haeyo?',
        uzbek: 'Hozir nima qilyapsiz?'
      },
      {
        speaker: 'Jasur',
        korean: '도서관에서 한국어를 공부해요.',
        romanization: 'Doseogwan-eseo hangugeo-reul gongbuhaeyo.',
        uzbek: 'Kutubxonada koreys tilini o\'rganyapman.'
      },
      {
        speaker: 'Sora',
        korean: '점심 먹었어요? 같이 식당에 갈래요?',
        romanization: 'Jeomsim meogeosseoyo? Gachi sikdang-e gallae-yo?',
        uzbek: 'Tushlik qildingizmi? Birga oshxonaga boramizmi?'
      }
    ],
    grammar: [
      {
        title: 'Hozirgi Zamon: ~아요 / ~어요 / ~해요',
        rule: 'O\'zakdagi oxirgi unli ㅏ yoki ㅗ bo\'lsa -> ~아요 | Boshqa unlilar -> ~어요 | 하다 fe\'llari -> ~해요',
        explanation: 'Koreys tilidagi eng ko\'p ishlatiladigan zamon qo\'shimchasi. Masalan: 가다 (bormoq) -> 가요 (boraman); 먹다 (yemoq) -> 먹어요 (yeyman); 공부하다 (o\'qimoq) -> 공부해요 (o\'qiyman).',
        examples: [
          { korean: '사과를 먹어요.', romanization: 'Sagwa-reul meogeoyo.', uzbek: 'Olma yeyman.' },
          { korean: '친구를 만나요.', romanization: 'Chingu-reul mannayo.', uzbek: 'Do\'stim bilan uchrashaman.' }
        ]
      },
      {
        title: 'Joyda harakat qilish: ~에서',
        rule: 'Joy nomi + 에서',
        explanation: 'Biror joyda faoliyat yoki ish-harakat sodir bo\'lganda ishlatiladi ("-da" ma\'nosida). Masalan: 집에서 (uyda), 회사에서 (kompaniyada/ishda).',
        examples: [
          { korean: '회사에서 일해요.', romanization: 'Hoesa-eseo ilhaeyo.', uzbek: 'Kompaniyada ishlayman.' },
          { korean: '집에서 쉬어요.', romanization: 'Jib-eseo swieoyo.', uzbek: 'Uyda dam olyapman.' }
        ]
      }
    ],
    vocabulary: [
      { korean: '가다 / 오다', romanization: 'gada / oda', uzbek: 'Bormoq / Kelmoq' },
      { korean: '먹다 / 마시다', romanization: 'meokda / masida', uzbek: 'Yemoq / Ichmoq' },
      { korean: '일하다 / 쉬다', romanization: 'ilhada / swida', uzbek: 'Ishlamoq / Dam olmoq' },
      { korean: '공부하다', romanization: 'gongbuhada', uzbek: 'Dars qilmoq / O\'rganmoq' },
      { korean: '보다', romanization: 'boda', uzbek: 'Ko\'rmoq / Qamoq' },
      { korean: '자다', romanization: 'jada', uzbek: 'Uxlamoq' }
    ],
    tips: [
      'Koreys tilida gap strukturasi SOV (Ega + To\'ldiruvchi + Fe\'l). Fe\'l har doim gap oxirida keladi!'
    ]
  },
  {
    id: 5,
    level: 'O\'rta (Level 2)',
    title: 'Restoran, Kafe va Menyudan Buyurtma Qilish',
    koreanTitle: '식당과 카페에서 주문하기',
    description: 'Koreya restoranlarida o\'zini erkin his qilish, taomlar turlari, ta\'mlarni ifodalash va to\'lov qilish iboralari.',
    estimatedMinutes: 30,
    objectives: [
      'Ofitsiantni chaqirish (여기요 / 저기요)',
      'Achchiqlik darajasini aytish (맵지 않게 해주세요)',
      'Taom va ichimliklarni aniq buyurtma qilish',
      'Hisobni to\'lash va chek so\'rash'
    ],
    dialogue: [
      {
        speaker: 'Mijoz',
        korean: '여기요! 비빔밥 하나하고 김치찌개 하나 주세요.',
        romanization: 'Yeogiyo! Bibimbap hana-hago gimchijjigae hana juseyo.',
        uzbek: 'Kechirasiz! Bitta bibimbap va bitta kimchijjigae bering.'
      },
      {
        speaker: 'Xizmatchi',
        korean: '네, 찌개는 좀 매운데 괜찮으세요?',
        romanization: 'Ne, jjigaeneun jom maeunde gwaenchaneuseyo?',
        uzbek: 'Xo\'p, sho\'rva biroz achchiq, sizga bo\'laveradimi?'
      },
      {
        speaker: 'Mijoz',
        korean: '덜 맵게 해주세요. 그리고 물 좀 더 주세요.',
        romanization: 'Deol maepge hae-juseyo. Geurigo mul jom deo juseyo.',
        uzbek: 'Kamroq achchiq qilib bering. Va yana ozgina suv bersangiz.'
      }
    ],
    grammar: [
      {
        title: 'Iltimos shakli: ~(으)세요 / 주다',
        rule: 'Fe\'l o\'zagi + (으)세요 | Narsa + 주세요',
        explanation: 'Hurmat bilan iltimos qilish yoki buyurtma berishda ishlatiladi. Masalan: 앉으세요 (o\'tiring), 주세요 (bering).',
        examples: [
          { korean: '메뉴판 좀 주세요.', romanization: 'Menyupan jom juseyo.', uzbek: 'Iltimos, menyuni bering.' },
          { korean: '계산해 주세요.', romanization: 'Gyesanhae juseyo.', uzbek: 'Iltimos, hisob-kitob qilib bering.' }
        ]
      },
      {
        title: 'Bog\'lovchi qo\'shimcha: ~하고 / ~와/과',
        rule: 'Ot + 하고 ("va", "bilan")',
        explanation: 'Ikki yoki undan ortiq narsani bog\'lashda ishlatiladi.',
        examples: [
          { korean: '불고기하고 밥', romanization: 'bulgogi-hago bap', uzbek: 'Bulgogi va guruch' },
          { korean: '물하고 콜라', romanization: 'mul-hago kolla', uzbek: 'Suv va kola' }
        ]
      }
    ],
    vocabulary: [
      { korean: '맛있어요', romanization: 'masisseoyo', uzbek: 'Mazali / Shirin' },
      { korean: '맛없어요', romanization: 'maseopseoyo', uzbek: 'Bemaza' },
      { korean: '매워요', romanization: 'maewoyo', uzbek: 'Achchiq' },
      { korean: '달아요', romanization: 'darayo', uzbek: 'Shirin (shakarlik)' },
      { korean: '계산서', romanization: 'gyesanseo', uzbek: 'Hisob varaqasi (chek)' },
      { korean: '카드', romanization: 'kadeu', uzbek: 'Plastik karta' }
    ],
    tips: [
      'Koreya restoranlarida stolda qizil qo\'ng\'iroqcha (bel) bo\'ladi, ofitsiantni qichqirmasdan o\'sha tugmani bosib chaqirish qulay.'
    ]
  },
  {
    id: 6,
    level: 'Maxsus (EPS-TOPIK)',
    title: 'EPS-TOPIK: Ish Joyi, Zavod va Xavfsizlik Qoidalari',
    koreanTitle: '직장 생활과 안전 수칙 (EPS-TOPIK)',
    description: 'Janubiy Koreyada ishchi viza (E-9) bilan borayotganlar uchun maxsus: zavod terminologiyasi, asbob-uskunalar, buyruqlar va xavfsizlik ko\'rsatmalari.',
    estimatedMinutes: 40,
    objectives: [
      'Zavod va ishlab chiqarishdagi asosiy asboblar nomlari',
      'Boshliqning ko\'rsatmalari va buyruqlarini tushunish',
      'Xavfsizlik qoidalari: himoya ko\'zoynagi, kaska, qo\'lqop',
      'EPS-TOPIK imtihonida eng ko\'p tushadigan savollar modeli'
    ],
    dialogue: [
      {
        speaker: 'Boshliq (Banjangnim)',
        korean: '바호디르 씨, 작업 전에 안전모하고 안전화를 꼭 착용하세요.',
        romanization: 'Bahodir ssi, jageop jeone anjeonmo-hago anjeonhwa-reul kkok chagyonghaseyo.',
        uzbek: 'Bahodir, ishdan oldin himoya kaskasi va maxsus poyabzalni albatta kiying.'
      },
      {
        speaker: 'Ishchi (Bahodir)',
        korean: '네, 반장님! 준비 다 끝났습니다. 오늘 어떤 기계를 돌립니까?',
        romanization: 'Ne, banjangnim! Junbi da kkeutnatseumnida. Oneul eotteon gigye-reul dollimnikka?',
        uzbek: 'Xo\'p, usta aka! Barcha tayyorgarlik tugadi. Bugun qaysi uskunani ishlatamiz?'
      },
      {
        speaker: 'Banjangnim',
        korean: '여기 프레스 기계 조심하고, 비상시에는 이 빨간 버튼을 누르세요.',
        romanization: 'Yeogi peureseu gigye josimhago, bisangsi-eneun i ppalgan beoteun-eul nureuseyo.',
        uzbek: 'Bu press mashinasidan ehtiyot bo\'ling, favqulodda holatda esa mana bu qizil tugmani bosing.'
      }
    ],
    grammar: [
      {
        title: 'Shart va Zaruriyat: ~아/어야 되다 (하다)',
        rule: 'Fe\'l o\'zagi + 아/어야 돼요 ("kerak", "shart")',
        explanation: 'Biror ishni qilish majburiyligini bildiradi. Zavodda qoidalar va tartib uchun juda ko\'p qo\'llaniladi.',
        examples: [
          { korean: '안전 장갑을 껴야 해요.', romanization: 'Anjeon jang-gab-eul kyeoya haeyo.', uzbek: 'Xavfsizlik qo\'lqopini kiyish shart.' },
          { korean: '기계를 꺼야 돼요.', romanization: 'Gigye-reul kkeoya dwaeyo.', uzbek: 'Uskunani o\'chirish kerak.' }
        ]
      },
      {
        title: 'Taqiqlov shakli: ~지 마세요',
        rule: 'Fe\'l o\'zagi + 지 마세요 ("qilmang")',
        explanation: 'Xavfli harakatlardan ogohlantirishda ishlatiladi.',
        examples: [
          { korean: '손을 대지 마세요.', romanization: 'Son-eul daeji maseyo.', uzbek: 'Qo\'lingizni tekkizmang!' },
          { korean: '담배를 피우지 마세요.', romanization: 'Dambaereul piuji maseyo.', uzbek: 'Chekmang!' }
        ]
      }
    ],
    vocabulary: [
      { korean: '안전모', romanization: 'anjeonmo', uzbek: 'Xavfsizlik kaskasi' },
      { korean: '안전화', romanization: 'anjeonhwa', uzbek: 'Maxsus himoya etik/poyabzal' },
      { korean: '안전장갑', romanization: 'anjeonjanggap', uzbek: 'Himoya qo\'lqoplari' },
      { korean: '반장님', romanization: 'banjangnim', uzbek: 'Sex boshlig\'i / Usta (brigadir)' },
      { korean: '기계', romanization: 'gigye', uzbek: 'Mashina / Stanok / Uskuna' },
      { korean: '작업', romanization: 'jageop', uzbek: 'Ish / Mehnat jarayoni' },
      { korean: '스위치', romanization: 'seuwichi', uzbek: 'Ulagich / Tugma' },
      { korean: '위험', romanization: 'wiheom', uzbek: 'Xavf / Xatar' }
    ],
    tips: [
      'EPS-TOPIK imtihonida rasmli savollar (qurilish mollari, zavod asboblari) 30% dan ortiq balni tashkil etadi.',
      'Koreyada ish joyida xavfsizlik qoidalariga rioya qilish jarohatlarning oldini oladi va ish beruvchi hurmatini qozonadi.'
    ]
  }
];
