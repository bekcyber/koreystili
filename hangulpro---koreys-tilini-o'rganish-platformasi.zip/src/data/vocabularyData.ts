import { Flashcard } from '../types';

export const VOCABULARY_LIST: Flashcard[] = [
  // Greetings
  {
    id: 'g1',
    korean: '안녕하세요',
    romanization: 'annyeonghaseyo',
    uzbek: 'Salom / Assalomu alaykum',
    category: 'greeting',
    exampleSentence: '선생님, 안녕하세요!',
    exampleTranslation: 'Ustoz, assalomu alaykum!'
  },
  {
    id: 'g2',
    korean: '감사합니다',
    romanization: 'gamsahamnida',
    uzbek: 'Rahmat / Tashakkur',
    category: 'greeting',
    exampleSentence: '도와주셔서 감사합니다.',
    exampleTranslation: 'Yordamingiz uchun rahmat.'
  },
  {
    id: 'g3',
    korean: '죄송합니다',
    romanization: 'joesonghamnida',
    uzbek: 'Kechirasiz / Uzr',
    category: 'greeting',
    exampleSentence: '늦어서 죄송합니다.',
    exampleTranslation: 'Kech qolganim uchun uzr so\'rayman.'
  },
  {
    id: 'g4',
    korean: '반갑습니다',
    romanization: 'bangapseumnida',
    uzbek: 'Tanishganimdan xursandman',
    category: 'greeting',
    exampleSentence: '만나서 반갑습니다.',
    exampleTranslation: 'Uchrashganimizdan xursandman.'
  },
  {
    id: 'g5',
    korean: '잘 지내세요?',
    romanization: 'jal jinaeseyo?',
    uzbek: 'Yaxshi yuribsizmi? / Ishlar yaxshimi?',
    category: 'greeting',
    exampleSentence: '요즘 잘 지내세요?',
    exampleTranslation: 'Shu kunlarda yaxshi yuribsizmi?'
  },
  {
    id: 'g6',
    korean: '또 만나요',
    romanization: 'tto mannayo',
    uzbek: 'Yana ko\'rishguncha',
    category: 'greeting',
    exampleSentence: '내일 또 만나요.',
    exampleTranslation: 'Ertaga yana ko\'rishguncha.'
  },

  // Daily
  {
    id: 'd1',
    korean: '사람',
    romanization: 'saram',
    uzbek: 'Inson / Odam',
    category: 'daily',
    exampleSentence: '좋은 사람이에요.',
    exampleTranslation: 'Yaxshi inson.'
  },
  {
    id: 'd2',
    korean: '친구',
    romanization: 'chingu',
    uzbek: 'Do\'st',
    category: 'daily',
    exampleSentence: '우리는 친한 친구예요.',
    exampleTranslation: 'Biz qadrdon do\'stlarmiz.'
  },
  {
    id: 'd3',
    korean: '가족',
    romanization: 'gajok',
    uzbek: 'Oila',
    category: 'daily',
    exampleSentence: '가족이 보고 싶어요.',
    exampleTranslation: 'Oilamni sog\'indim.'
  },
  {
    id: 'd4',
    korean: '집',
    romanization: 'jip',
    uzbek: 'Uy',
    category: 'daily',
    exampleSentence: '지금 집에 가요.',
    exampleTranslation: 'Hozir uyga ketyapman.'
  },
  {
    id: 'd5',
    korean: '시간',
    romanization: 'sigan',
    uzbek: 'Vaqt / Soat',
    category: 'daily',
    exampleSentence: '시간이 없어요.',
    exampleTranslation: 'Vaqtim yo\'q.'
  },
  {
    id: 'd6',
    korean: '오늘',
    romanization: 'oneul',
    uzbek: 'Bugun',
    category: 'daily',
    exampleSentence: '오늘 날씨가 좋아요.',
    exampleTranslation: 'Bugun havo yaxshi.'
  },
  {
    id: 'd7',
    korean: '내일',
    romanization: 'naeil',
    uzbek: 'Ertaga',
    category: 'daily',
    exampleSentence: '내일 시험이 있어요.',
    exampleTranslation: 'Ertaga imtihonim bor.'
  },

  // Food
  {
    id: 'f1',
    korean: '물',
    romanization: 'mul',
    uzbek: 'Suv',
    category: 'food',
    exampleSentence: '시원한 물 한 잔 주세요.',
    exampleTranslation: 'Bir stakan muzdek suv bering.'
  },
  {
    id: 'f2',
    korean: '밥',
    romanization: 'bap',
    uzbek: 'Guruch / Ovqat',
    category: 'food',
    exampleSentence: '밥 먹었어요?',
    exampleTranslation: 'Ovqatlandingizmi?'
  },
  {
    id: 'f3',
    korean: '김치',
    romanization: 'gimchi',
    uzbek: 'Kimchi (achchiq karam gazak)',
    category: 'food',
    exampleSentence: '한국 김치는 매워요.',
    exampleTranslation: 'Koreys kimchisi achchiq.'
  },
  {
    id: 'f4',
    korean: '고기',
    romanization: 'gogi',
    uzbek: 'Go\'sht',
    category: 'food',
    exampleSentence: '소고기를 좋아해요.',
    exampleTranslation: 'Mol go\'shtini yaxshi ko\'raman.'
  },
  {
    id: 'f5',
    korean: '빵',
    romanization: 'ppang',
    uzbek: 'Non',
    category: 'food',
    exampleSentence: '아침에 빵을 먹어요.',
    exampleTranslation: 'Ertalab non yeyman.'
  },
  {
    id: 'f6',
    korean: '사과',
    romanization: 'sagwa',
    uzbek: 'Olma',
    category: 'food',
    exampleSentence: '사과가 달고 맛있어요.',
    exampleTranslation: 'Olma shirin va mazali.'
  },

  // Travel
  {
    id: 't1',
    korean: '공항',
    romanization: 'gonghang',
    uzbek: 'Aeroport',
    category: 'travel',
    exampleSentence: '인천공항에 도착했어요.',
    exampleTranslation: 'Incheon aeroportiga yetib keldim.'
  },
  {
    id: 't2',
    korean: '지하철',
    romanization: 'jihacheol',
    uzbek: 'Metro',
    category: 'travel',
    exampleSentence: '지하철역이 어디예요?',
    exampleTranslation: 'Metro bekati qayerda?'
  },
  {
    id: 't3',
    korean: '버스',
    romanization: 'beoseu',
    uzbek: 'Avtobus',
    category: 'travel',
    exampleSentence: '버스를 타고 가요.',
    exampleTranslation: 'Avtobusga o\'tirib ketyapman.'
  },
  {
    id: 't4',
    korean: '화장실',
    romanization: 'hwajangsil',
    uzbek: 'Hojatxona',
    category: 'travel',
    exampleSentence: '화장실이 어디에 있어요?',
    exampleTranslation: 'Hojatxona qayerda joylashgan?'
  },
  {
    id: 't5',
    korean: '호텔',
    romanization: 'hotel',
    uzbek: 'Mehmonxona',
    category: 'travel',
    exampleSentence: '호텔을 예약했어요.',
    exampleTranslation: 'Mehmonxonani band qildim.'
  },

  // Numbers & Money
  {
    id: 'n1',
    korean: '하나, 둘, 셋',
    romanization: 'hana, dul, set',
    uzbek: 'Bir, ikki, uch (Sof koreys)',
    category: 'numbers',
    exampleSentence: '사과 세 개 주세요.',
    exampleTranslation: 'Uch dona olma bering.'
  },
  {
    id: 'n2',
    korean: '일, 이, 삼',
    romanization: 'il, i, sam',
    uzbek: 'Bir, ikki, uch (Sin-koreys)',
    category: 'numbers',
    exampleSentence: '삼월 일일',
    exampleTranslation: '1-mart kuni'
  },
  {
    id: 'n3',
    korean: '돈',
    romanization: 'don',
    uzbek: 'Pul',
    category: 'numbers',
    exampleSentence: '돈을 아껴 써야 해요.',
    exampleTranslation: 'Pulni tejab ishlatish kerak.'
  },
  {
    id: 'n4',
    korean: '원',
    romanization: 'won',
    uzbek: 'Von (₩ Koreya valyutasi)',
    category: 'numbers',
    exampleSentence: '만 원이에요.',
    exampleTranslation: '10,000 von.'
  },

  // Work & EPS-TOPIK
  {
    id: 'w1',
    korean: '공장',
    romanization: 'gongjang',
    uzbek: 'Zavod / Fabrika',
    category: 'work_eps',
    exampleSentence: '자동차 부품 공장에서 일해요.',
    exampleTranslation: 'Avtomobil ehtiyot qismlari zavodida ishlayman.'
  },
  {
    id: 'w2',
    korean: '안전',
    romanization: 'anjeon',
    uzbek: 'Xavfsizlik',
    category: 'work_eps',
    exampleSentence: '안전이 제일 중요합니다.',
    exampleTranslation: 'Xavfsizlik eng muhimi.'
  },
  {
    id: 'w3',
    korean: '사장님',
    romanization: 'sajangnim',
    uzbek: 'Xo\'jayin / Direktor',
    category: 'work_eps',
    exampleSentence: '사장님께 보고드렸습니다.',
    exampleTranslation: 'Xo\'jayinga hisobot berdim.'
  },
  {
    id: 'w4',
    korean: '월급',
    romanization: 'wolgeup',
    uzbek: 'Oylik maosh',
    category: 'work_eps',
    exampleSentence: '매월 10일은 월급날이에요.',
    exampleTranslation: 'Har oyning 10-sanasi maosh kuni.'
  },
  {
    id: 'w5',
    korean: '야근',
    romanization: 'yageun',
    uzbek: 'Tungi smena / Qo\'shimcha ish vaqti',
    category: 'work_eps',
    exampleSentence: '오늘 야근이 있어요.',
    exampleTranslation: 'Bugun qo\'shimcha tungi ish bor.'
  },
  {
    id: 'w6',
    korean: '조심하세요',
    romanization: 'josimhaseyo',
    uzbek: 'Ehtiyot bo\'ling',
    category: 'work_eps',
    exampleSentence: '뜨거우니까 조심하세요.',
    exampleTranslation: 'Issiq, ehtiyot bo\'ling.'
  }
];
