/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ActiveTab } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { HangulMaster } from './components/HangulMaster';
import { LessonsView } from './components/LessonsView';
import { FlashcardsView } from './components/FlashcardsView';
import { QuizArena } from './components/QuizArena';
import { TopikGuide } from './components/TopikGuide';
import { Footer } from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [userXp, setUserXp] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('hangul_pro_xp');
      return saved ? parseInt(saved, 10) : 150;
    }
    return 150;
  });

  const [completedLessons, setCompletedLessons] = useState<number[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('hangul_pro_completed_lessons');
      return saved ? JSON.parse(saved) : [1];
    }
    return [1];
  });

  const [streakDays] = useState<number>(3);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('hangul_pro_xp', userXp.toString());
    } catch {
      // Ignore
    }
  }, [userXp]);

  useEffect(() => {
    try {
      localStorage.setItem('hangul_pro_completed_lessons', JSON.stringify(completedLessons));
    } catch {
      // Ignore
    }
  }, [completedLessons]);

  const handleCompleteLesson = (lessonId: number) => {
    if (!completedLessons.includes(lessonId)) {
      setCompletedLessons(prev => [...prev, lessonId]);
      setUserXp(prev => prev + 50);
    } else {
      setUserXp(prev => prev + 10);
    }
  };

  const handleLearnWord = () => {
    setUserXp(prev => prev + 10);
  };

  const handleCompleteQuiz = (xpEarned: number) => {
    setUserXp(prev => prev + xpEarned);
  };

  // Scroll to top when changing tabs
  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        userXp={userXp}
        streakDays={streakDays}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            <Hero setActiveTab={handleTabChange} />
            <HangulMaster />
            <LessonsView
              onCompleteLesson={handleCompleteLesson}
              completedLessons={completedLessons}
            />
            <TopikGuide />
          </>
        )}

        {activeTab === 'hangul' && <HangulMaster />}

        {activeTab === 'lessons' && (
          <LessonsView
            onCompleteLesson={handleCompleteLesson}
            completedLessons={completedLessons}
          />
        )}

        {activeTab === 'flashcards' && (
          <FlashcardsView onLearnWord={handleLearnWord} />
        )}

        {activeTab === 'quiz' && (
          <QuizArena onCompleteQuiz={handleCompleteQuiz} />
        )}

        {activeTab === 'topik' && <TopikGuide />}
      </main>

      {/* Footer */}
      <Footer setActiveTab={handleTabChange} />
    </div>
  );
}
