import test from 'node:test';
import assert from 'node:assert/strict';
import { composeHangul, decomposeHangul, calculateQuizResult } from './hangul';

test('composeHangul correctly builds syllables without batchim', () => {
  // ㄱ (0) + ㅏ (0) = 가
  assert.equal(composeHangul('ㄱ', 'ㅏ', ''), '가');
  // ㄴ + ㅏ = 나
  assert.equal(composeHangul('ㄴ', 'ㅏ', ''), '나');
  // ㅅ + ㅏ = 사
  assert.equal(composeHangul('ㅅ', 'ㅏ', ''), '사');
});

test('composeHangul correctly builds syllables with batchim (final consonant)', () => {
  // ㅎ + ㅏ + ㄴ = 한
  assert.equal(composeHangul('ㅎ', 'ㅏ', 'ㄴ'), '한');
  // ㄱ + ㅡ + ㄹ = 글
  assert.equal(composeHangul('ㄱ', 'ㅡ', 'ㄹ'), '글');
  // ㅁ + ㅓ + ㄱ = 먹
  assert.equal(composeHangul('ㅁ', 'ㅓ', 'ㄱ'), '먹');
});

test('decomposeHangul breaks down syllables into constituents', () => {
  const parts1 = decomposeHangul('한');
  assert.deepEqual(parts1, { choseong: 'ㅎ', jungseong: 'ㅏ', jongseong: 'ㄴ' });

  const parts2 = decomposeHangul('가');
  assert.deepEqual(parts2, { choseong: 'ㄱ', jungseong: 'ㅏ', jongseong: '' });

  const nonHangul = decomposeHangul('A');
  assert.equal(nonHangul, null);
});

test('calculateQuizResult calculates correct scores and ranks', () => {
  const high = calculateQuizResult(10, 10);
  assert.equal(high.percentage, 100);
  assert.equal(high.passed, true);
  assert.equal(high.xp, 300); // 10*25 + 50 bonus

  const mid = calculateQuizResult(7, 10);
  assert.equal(mid.percentage, 70);
  assert.equal(mid.passed, true);

  const low = calculateQuizResult(2, 10);
  assert.equal(low.percentage, 20);
  assert.equal(low.passed, false);
});
