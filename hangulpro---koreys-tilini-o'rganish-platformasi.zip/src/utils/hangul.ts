/**
 * Hangul (Korean Alphabet) syllable composition and utility logic
 */

export const CHOSEONG = [
  'ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ',
  'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'
] as const;

export const JUNGSEONG = [
  'ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ', 'ㅗ', 'ㅘ',
  'ㅙ', 'ㅚ', 'ㅛ', 'ㅜ', 'ㅝ', 'ㅞ', 'ㅟ', 'ㅠ', 'ㅡ', 'ㅢ', 'ㅣ'
] as const;

export const JONGSEONG = [
  '', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ',
  'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ', 'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ',
  'ㅆ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'
] as const;

const HANGUL_BASE = 0xAC00;

/**
 * Compose initial consonant, vowel, and optional final consonant into a Korean syllable
 */
export function composeHangul(
  choseongChar: string,
  jungseongChar: string,
  jongseongChar: string = ''
): string {
  const cIndex = CHOSEONG.indexOf(choseongChar as typeof CHOSEONG[number]);
  const jIndex = JUNGSEONG.indexOf(jungseongChar as typeof JUNGSEONG[number]);
  const finalIndex = JONGSEONG.indexOf(jongseongChar as typeof JONGSEONG[number]);

  if (cIndex === -1 || jIndex === -1 || finalIndex === -1) {
    return choseongChar + jungseongChar + jongseongChar;
  }

  const codePoint = HANGUL_BASE + (cIndex * 21 + jIndex) * 28 + finalIndex;
  return String.fromCharCode(codePoint);
}

/**
 * Decompose a Hangul syllable into its constituent parts
 */
export function decomposeHangul(char: string): { choseong: string; jungseong: string; jongseong: string } | null {
  if (!char || char.length === 0) return null;
  const code = char.charCodeAt(0);
  if (code < 0xAC00 || code > 0xD7A3) return null;

  const syllableIndex = code - HANGUL_BASE;
  const jongseongIndex = syllableIndex % 28;
  const jungseongIndex = Math.floor((syllableIndex - jongseongIndex) / 28) % 21;
  const choseongIndex = Math.floor((syllableIndex - jongseongIndex) / (28 * 21));

  return {
    choseong: CHOSEONG[choseongIndex] || '',
    jungseong: JUNGSEONG[jungseongIndex] || '',
    jongseong: JONGSEONG[jongseongIndex] || ''
  };
}

/**
 * Calculate user quiz score, percentage, and XP reward
 */
export function calculateQuizResult(correctCount: number, totalQuestions: number) {
  if (totalQuestions <= 0) {
    return { score: 0, percentage: 0, xp: 0, passed: false, rank: 'Boshlang\'ich' };
  }
  const percentage = Math.round((correctCount / totalQuestions) * 100);
  const xp = correctCount * 25 + (percentage >= 80 ? 50 : 0);
  const passed = percentage >= 70;

  let rank = "Boshlang'ich (A1)";
  if (percentage >= 90) rank = "A'lo daraja - TOPIK 2/3 tayyor";
  else if (percentage >= 70) rank = "Yaxshi - TOPIK 1 darajasi";
  else if (percentage >= 50) rank = "O'rtacha - Yana mashq qiling";

  return {
    score: correctCount,
    percentage,
    xp,
    passed,
    rank
  };
}

/**
 * Helper to get romanization and Uzbek pronunciation note
 */
export const ROMANIZATION_MAP: Record<string, { uzbek: string; roman: string; example: string }> = {
  'ㄱ': { uzbek: 'G / K (so\'z boshida K, o\'rtada G)', roman: 'g/k', example: '고기 (gogi - go\'sht)' },
  'ㄴ': { uzbek: 'N', roman: 'n', example: '나무 (namu - daraxt)' },
  'ㄷ': { uzbek: 'D / T (so\'z boshida T, o\'rtada D)', roman: 'd/t', example: '다리 (dari - ko\'prik/oyoq)' },
  'ㄹ': { uzbek: 'R / L (so\'z boshida/o\'rtada R, bo\'g\'in oxirida L)', roman: 'r/l', example: '라디오 (radio)' },
  'ㅁ': { uzbek: 'M', roman: 'm', example: '마음 (maum - qalb)' },
  'ㅂ': { uzbek: 'B / P (so\'z boshida P, o\'rtada B)', roman: 'b/p', example: '바다 (bada - dengiz)' },
  'ㅅ': { uzbek: 'S (i, ya, ye, yo, yu oldida Sh)', roman: 's', example: '사람 (saram - odam)' },
  'ㅇ': { uzbek: 'Tovushsiz (bo\'g\'in boshida) / NG (bo\'g\'in oxirida)', roman: 'ng', example: '아이 (ai - bola), 강 (gang - daryo)' },
  'ㅈ': { uzbek: 'J / Ch (so\'z boshida Ch, o\'rtada J)', roman: 'j', example: '지도 (jido - xarita)' },
  'ㅊ': { uzbek: 'CH (kuchli)', roman: 'ch', example: '차 (cha - choy/mashina)' },
  'ㅋ': { uzbek: 'K (havoli, kuchli K)', roman: 'k', example: '코 (ko - burun)' },
  'ㅌ': { uzbek: 'T (havoli, kuchli T)', roman: 't', example: '타다 (tada - minmoq)' },
  'ㅍ': { uzbek: 'P (havoli, kuchli P)', roman: 'p', example: '파 (pa - piyoz)' },
  'ㅎ': { uzbek: 'H', roman: 'h', example: '하늘 (haneul - osmon)' },
  'ㅏ': { uzbek: 'A', roman: 'a', example: '아이 (ai - bola)' },
  'ㅓ': { uzbek: 'O (ochiq O)', roman: 'eo', example: '어머니 (eomeoni - ona)' },
  'ㅗ': { uzbek: 'O\' (lablangan yopiq O\')', roman: 'o', example: '오이 (oi - bodring)' },
  'ㅜ': { uzbek: 'U', roman: 'u', example: '우유 (uyu - sut)' },
  'ㅡ': { uzbek: 'I (chuqur, tishlar orasidan)', roman: 'eu', example: '음식 (eumsik - taom)' },
  'ㅣ': { uzbek: 'I', roman: 'i', example: '이름 (ireum - ism)' },
};
