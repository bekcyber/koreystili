import React, { useState } from 'react';
import { HANGUL_VOWELS, HANGUL_CONSONANTS, BATCHIM_RULES } from '../data/hangulData';
import { HangulLetter } from '../types';
import { Volume2, RefreshCw, Sparkles, BookOpen, Layers } from 'lucide-react';
import { playKoreanAudio } from '../utils/audio';
import { composeHangul, CHOSEONG, JUNGSEONG, JONGSEONG } from '../utils/hangul';

export const HangulMaster: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'vowels' | 'consonants' | 'batchim' | 'builder'>('vowels');
  const [selectedLetter, setSelectedLetter] = useState<HangulLetter | null>(HANGUL_VOWELS[0]);

  // Builder states
  const [builderInitial, setBuilderInitial] = useState<string>('ㅎ');
  const [builderVowel, setBuilderVowel] = useState<string>('ㅏ');
  const [builderFinal, setBuilderFinal] = useState<string>('ㄴ');

  const composedSyllable = composeHangul(builderInitial, builderVowel, builderFinal);

  const handleLetterClick = (letter: HangulLetter) => {
    setSelectedLetter(letter);
    playKoreanAudio(letter.exampleWord || letter.char);
  };

  return (
    <section className="py-12 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-700 tracking-wide uppercase mb-2">
            <span>Interaktiv Alifbo Markazi</span>
            <span aria-hidden="true">·</span>
            <span>한글 마스터</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Koreys Alifbosi: Harflar va Talaffuz
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Harflarni bosing, toza talaffuzni eshiting va bo'g'in yasash qoidalarini amalda sinab ko'ring.
          </p>
        </div>

        {/* Sub-navigation Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          <button
            onClick={() => setActiveSubTab('vowels')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'vowels'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <span>Unlilar (모음)</span>
            <span className="opacity-75 text-[10px]">15 ta</span>
          </button>

          <button
            onClick={() => setActiveSubTab('consonants')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'consonants'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <span>Undoshlar (자음)</span>
            <span className="opacity-75 text-[10px]">19 ta</span>
          </button>

          <button
            onClick={() => setActiveSubTab('batchim')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'batchim'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Batchim Qoidalari (받침)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('builder')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'builder'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Bo'g'in Konstruktori</span>
          </button>
        </div>

        {/* Content based on sub-tab */}
        {activeSubTab === 'vowels' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Letter Grid */}
            <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200">
              <div className="text-xs font-medium text-slate-500 mb-4 flex items-center justify-between">
                <span>Unli harfni tanlang va talaffuzini eshiting:</span>
                <span className="text-indigo-600">Bosing: Audio yangraydi</span>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                {HANGUL_VOWELS.map((vowel) => {
                  const isSelected = selectedLetter?.id === vowel.id;
                  return (
                    <button
                      key={vowel.id}
                      onClick={() => handleLetterClick(vowel)}
                      className={`p-3 rounded-xl border text-center transition-all group flex flex-col items-center justify-center ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/50 shadow-sm ring-1 ring-indigo-600'
                          : 'border-slate-200 bg-white hover:border-indigo-300 hover:bg-slate-50'
                      }`}
                    >
                      <span className="text-2xl sm:text-3xl font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                        {vowel.char}
                      </span>
                      <span className="text-xs font-semibold text-indigo-600 mt-1 uppercase">
                        {vowel.name}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        [{vowel.romanization}]
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Letter Details Card */}
            <div className="lg:col-span-4">
              {selectedLetter ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 h-full flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
                      <div>
                        <span className="text-4xl font-extrabold text-slate-900">
                          {selectedLetter.char}
                        </span>
                        <span className="ml-3 text-sm font-semibold text-indigo-600 uppercase">
                          {selectedLetter.name}
                        </span>
                      </div>
                      <button
                        onClick={() => playKoreanAudio(selectedLetter.exampleWord || selectedLetter.char)}
                        className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-colors"
                        title="Ovozini eshitish"
                      >
                        <Volume2 className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="space-y-3 text-xs sm:text-sm">
                      <div>
                        <div className="text-xs text-slate-400 font-medium">O'zbekcha talaffuzi:</div>
                        <div className="font-semibold text-slate-800">{selectedLetter.uzbekSound}</div>
                      </div>

                      <div>
                        <div className="text-xs text-slate-400 font-medium">Izoh va yozilishi:</div>
                        <div className="text-slate-600 text-xs leading-relaxed">{selectedLetter.description}</div>
                      </div>

                      <div className="pt-3 border-t border-slate-100">
                        <div className="text-xs text-slate-400 font-medium mb-1">Namunaviy so'z:</div>
                        <div className="p-3 bg-slate-50 rounded-xl flex items-center justify-between">
                          <div>
                            <div className="text-base font-bold text-slate-900">
                              {selectedLetter.exampleWord}
                            </div>
                            <div className="text-xs text-slate-500">
                              [{selectedLetter.examplePronunciation}] - {selectedLetter.exampleTranslation}
                            </div>
                          </div>
                          <button
                            onClick={() => playKoreanAudio(selectedLetter.exampleWord)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-100 text-[11px] text-slate-400 text-center">
                    Maslahat: Har bir harfni ovoz chiqarib takrorlang!
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        )}

        {/* Consonants Tab */}
        {activeSubTab === 'consonants' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200">
              <div className="text-xs font-medium text-slate-500 mb-4 flex items-center justify-between">
                <span>Undosh harflar (Oddiy va Qo'shaloq):</span>
                <span className="text-indigo-600">Bosing: Audio yangraydi</span>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                {HANGUL_CONSONANTS.map((consonant) => {
                  const isSelected = selectedLetter?.id === consonant.id;
                  return (
                    <button
                      key={consonant.id}
                      onClick={() => handleLetterClick(consonant)}
                      className={`p-3 rounded-xl border text-center transition-all group flex flex-col items-center justify-center ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/50 shadow-sm ring-1 ring-indigo-600'
                          : 'border-slate-200 bg-white hover:border-indigo-300 hover:bg-slate-50'
                      }`}
                    >
                      <span className="text-2xl sm:text-3xl font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                        {consonant.char}
                      </span>
                      <span className="text-xs font-semibold text-slate-700 mt-1">
                        {consonant.name.split(' ')[0]}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        [{consonant.romanization}]
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="lg:col-span-4">
              {selectedLetter ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 h-full flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
                      <div>
                        <span className="text-4xl font-extrabold text-slate-900">
                          {selectedLetter.char}
                        </span>
                        <span className="ml-3 text-sm font-semibold text-indigo-600">
                          {selectedLetter.name}
                        </span>
                      </div>
                      <button
                        onClick={() => playKoreanAudio(selectedLetter.exampleWord || selectedLetter.char)}
                        className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-colors"
                        title="Ovozini eshitish"
                      >
                        <Volume2 className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="space-y-3 text-xs sm:text-sm">
                      <div>
                        <div className="text-xs text-slate-400 font-medium">O'zbekcha talaffuzi:</div>
                        <div className="font-semibold text-slate-800">{selectedLetter.uzbekSound}</div>
                      </div>

                      <div>
                        <div className="text-xs text-slate-400 font-medium">Izoh va o'qilish holati:</div>
                        <div className="text-slate-600 text-xs leading-relaxed">{selectedLetter.description}</div>
                      </div>

                      <div className="pt-3 border-t border-slate-100">
                        <div className="text-xs text-slate-400 font-medium mb-1">Namunaviy so'z:</div>
                        <div className="p-3 bg-slate-50 rounded-xl flex items-center justify-between">
                          <div>
                            <div className="text-base font-bold text-slate-900">
                              {selectedLetter.exampleWord}
                            </div>
                            <div className="text-xs text-slate-500">
                              [{selectedLetter.examplePronunciation}] - {selectedLetter.exampleTranslation}
                            </div>
                          </div>
                          <button
                            onClick={() => playKoreanAudio(selectedLetter.exampleWord)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-100 text-[11px] text-slate-400 text-center">
                    Oddiy va qo'shaloq undoshlar (ㄲ, ㄸ, ㅃ, ㅆ, ㅉ) tarang aytiladi.
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        )}

        {/* Batchim Tab */}
        {activeSubTab === 'batchim' && (
          <div className="space-y-6">
            <div className="bg-indigo-50/70 border border-indigo-100 p-5 rounded-2xl">
              <h3 className="text-sm font-bold text-indigo-950 mb-1 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-indigo-600" />
                Batchim nima? (받침)
              </h3>
              <p className="text-xs sm:text-sm text-indigo-900 leading-relaxed">
                Koreys tilida bo'g'inning eng pastki qismiga yoziladigan undosh harflar <strong>Batchim</strong> deyiladi. 
                Koreys yozuvida 27 xil batchim bo'lishiga qaramay, ular bo'g'in oxirida faqat <strong>7 ta asosiy tovush</strong> kabi o'qiladi!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {BATCHIM_RULES.map((rule, idx) => (
                <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200">
                  <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-3">
                    <span className="text-lg font-bold text-indigo-600">
                      {rule.representativeSound}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {rule.letters.map((ltr, i) => (
                        <span key={i} className="px-2 py-0.5 bg-slate-100 text-slate-700 text-xs font-semibold rounded">
                          {ltr}
                        </span>
                      ))}
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 mb-4 min-h-[36px]">
                    {rule.uzbekExplanation}
                  </p>

                  <div className="space-y-2 pt-2 border-t border-slate-50">
                    <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Namunalar:
                    </div>
                    {rule.examples.map((ex, exIdx) => (
                      <div
                        key={exIdx}
                        className="flex items-center justify-between p-2 rounded-lg bg-slate-50 hover:bg-indigo-50/40 transition-colors text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-900 mr-2">{ex.word}</span>
                          <span className="text-slate-500 font-mono text-[11px] mr-2">{ex.reading}</span>
                          <span className="text-slate-600">{ex.meaning}</span>
                        </div>
                        <button
                          onClick={() => playKoreanAudio(ex.word)}
                          className="p-1 text-slate-400 hover:text-indigo-600"
                          title="Tinglash"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Syllable Builder Tab */}
        {activeSubTab === 'builder' && (
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 max-w-4xl mx-auto">
            <div className="text-center mb-6">
              <h3 className="text-lg sm:text-xl font-bold text-slate-900 mb-1">
                Interaktiv Bo'g'in Konstruktori
              </h3>
              <p className="text-xs sm:text-sm text-slate-500">
                Undosh, unli va batchimni tanlang. Tizim ularni haqiqiy koreyscha bo'g'inga birlashtiradi va ovozini eshittiradi.
              </p>
            </div>

            {/* Live Syllable Showcase Screen */}
            <div className="bg-gradient-to-br from-indigo-50 to-slate-50 border border-indigo-100 rounded-2xl p-6 text-center mb-8 relative">
              <div className="text-xs text-indigo-700 font-semibold uppercase tracking-wider mb-2">
                Hosil Bo'lgan Bo'g'in:
              </div>
              <div className="text-6xl sm:text-7xl font-extrabold text-slate-900 tracking-tight my-2">
                {composedSyllable}
              </div>

              <div className="flex items-center justify-center gap-3 mt-4">
                <button
                  onClick={() => playKoreanAudio(composedSyllable)}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl transition-colors flex items-center gap-2 shadow-sm"
                >
                  <Volume2 className="w-4 h-4" />
                  Ovozini Eshitish
                </button>

                <button
                  onClick={() => {
                    setBuilderInitial('ㅎ');
                    setBuilderVowel('ㅏ');
                    setBuilderFinal('ㄴ');
                  }}
                  className="px-4 py-2.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-xl transition-colors flex items-center gap-2"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
                  Qayta o'rnatish
                </button>
              </div>

              <div className="text-xs text-slate-500 mt-3 font-mono">
                Formula: {builderInitial} (bosh undosh) + {builderVowel} (unli) {builderFinal ? `+ ${builderFinal} (batchim)` : ''} = {composedSyllable}
              </div>
            </div>

            {/* Selectors Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Step 1: Choseong (Initial Consonant) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
                <div className="text-xs font-bold text-slate-800 mb-2">
                  1. Bosh Undosh ({CHOSEONG.length} ta)
                </div>
                <div className="grid grid-cols-5 gap-1.5 max-h-48 overflow-y-auto p-1">
                  {CHOSEONG.map((c) => (
                    <button
                      key={c}
                      onClick={() => setBuilderInitial(c)}
                      className={`p-2 rounded-lg text-sm font-bold transition-colors ${
                        builderInitial === c
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-800 hover:bg-indigo-50'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Jungseong (Vowel) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
                <div className="text-xs font-bold text-slate-800 mb-2">
                  2. O'rta Unli ({JUNGSEONG.length} ta)
                </div>
                <div className="grid grid-cols-5 gap-1.5 max-h-48 overflow-y-auto p-1">
                  {JUNGSEONG.map((v) => (
                    <button
                      key={v}
                      onClick={() => setBuilderVowel(v)}
                      className={`p-2 rounded-lg text-sm font-bold transition-colors ${
                        builderVowel === v
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-800 hover:bg-indigo-50'
                      }`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 3: Jongseong (Final Batchim) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
                <div className="text-xs font-bold text-slate-800 mb-2">
                  3. Batchim (ixtiyoriy)
                </div>
                <div className="grid grid-cols-5 gap-1.5 max-h-48 overflow-y-auto p-1">
                  {JONGSEONG.map((b, i) => (
                    <button
                      key={i}
                      onClick={() => setBuilderFinal(b)}
                      className={`p-2 rounded-lg text-sm font-bold transition-colors ${
                        builderFinal === b
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-800 hover:bg-indigo-50'
                      }`}
                    >
                      {b === '' ? 'Ø (yo\'q)' : b}
                    </button>
                  ))}
                </div>
              </div>

            </div>

          </div>
        )}

      </div>
    </section>
  );
};
