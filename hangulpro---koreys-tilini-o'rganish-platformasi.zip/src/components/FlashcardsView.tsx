import React, { useState } from 'react';
import { VOCABULARY_LIST } from '../data/vocabularyData';
import { Flashcard } from '../types';
import { Volume2, RotateCw, Check, ArrowLeft, ArrowRight, Bookmark, Sparkles } from 'lucide-react';
import { playKoreanAudio, playSoundEffect } from '../utils/audio';

interface FlashcardsViewProps {
  onLearnWord: () => void;
}

export const FlashcardsView: React.FC<FlashcardsViewProps> = ({ onLearnWord }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [knownWords, setKnownWords] = useState<string[]>([]);

  const filteredCards = activeCategory === 'all'
    ? VOCABULARY_LIST
    : VOCABULARY_LIST.filter(c => c.category === activeCategory);

  const currentCard: Flashcard = filteredCards[currentIndex] || filteredCards[0];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % filteredCards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + filteredCards.length) % filteredCards.length);
  };

  const toggleFlip = () => {
    setIsFlipped(!isFlipped);
    playSoundEffect('click');
  };

  const markKnown = () => {
    if (!knownWords.includes(currentCard.id)) {
      setKnownWords([...knownWords, currentCard.id]);
      onLearnWord();
      playSoundEffect('correct');
    }
    handleNext();
  };

  const isCurrentKnown = knownWords.includes(currentCard.id);

  return (
    <section className="py-12 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-700 tracking-wide uppercase mb-2">
            <span>Interaktiv Lug'at Kartochkalari</span>
            <span aria-hidden="true">·</span>
            <span>단어 카드</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Koreyscha So'z Boyligini Oshirish
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Kartochkani ag'daring, ma'nosi va namunaviy gapini ko'ring, audio talaffuzini tinglang.
          </p>
        </div>

        {/* Categories Bar */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 mb-8">
          {[
            { id: 'all', label: 'Barchasi', count: VOCABULARY_LIST.length },
            { id: 'greeting', label: 'Salomlashish', count: 6 },
            { id: 'food', label: 'Oziq-ovqat', count: 6 },
            { id: 'travel', label: 'Sayohat', count: 5 },
            { id: 'numbers', label: 'Sonlar & Pul', count: 4 },
            { id: 'work_eps', label: 'EPS-TOPIK (Ish)', count: 6 }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id);
                setCurrentIndex(0);
                setIsFlipped(false);
              }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
                activeCategory === cat.id
                  ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <span>{cat.label}</span>
              <span className="opacity-70 text-[10px] tabular-nums">({cat.count})</span>
            </button>
          ))}
        </div>

        {/* Progress Tracker */}
        <div className="max-w-xl mx-auto mb-4 flex items-center justify-between text-xs text-slate-500 font-medium">
          <div>
            Kartochka: <span className="text-slate-900 font-bold tabular-nums">{currentIndex + 1}</span> / {filteredCards.length}
          </div>
          <div className="flex items-center gap-1.5 text-emerald-600">
            <Check className="w-3.5 h-3.5" />
            <span>O'zlashtirilgan: <strong className="tabular-nums">{knownWords.length}</strong> ta</span>
          </div>
        </div>

        {/* 3D Flip Card Container */}
        <div className="max-w-xl mx-auto">
          <div
            onClick={toggleFlip}
            className="cursor-pointer min-h-[300px] sm:min-h-[320px] bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all p-8 flex flex-col justify-between relative select-none"
          >
            {/* Top Indicator */}
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase font-bold tracking-wider text-slate-400">
                {isFlipped ? 'Ma\'nosi va Misol' : 'Koreyscha So\'z'}
              </span>

              <div className="flex items-center gap-2">
                {isCurrentKnown && (
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Yodlandi ✓
                  </span>
                )}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    playKoreanAudio(currentCard.korean);
                  }}
                  className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                  title="Talaffuzni eshitish"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Card Body */}
            {!isFlipped ? (
              <div className="text-center py-6">
                <div className="text-4xl sm:text-5xl font-extrabold text-slate-900 mb-3 tracking-tight">
                  {currentCard.korean}
                </div>
                <div className="text-sm font-mono text-slate-400">
                  [{currentCard.romanization}]
                </div>
                <div className="text-xs text-indigo-600 mt-6 font-medium flex items-center justify-center gap-1.5">
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Ma'nosini ko'rish uchun kartani bosing</span>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 space-y-4">
                <div>
                  <div className="text-2xl sm:text-3xl font-bold text-slate-900">
                    {currentCard.uzbek}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    Koreyscha: {currentCard.korean} [{currentCard.romanization}]
                  </div>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 text-left">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-1">
                    Misol gap:
                  </div>
                  <div className="text-sm font-semibold text-slate-800 flex items-center justify-between">
                    <span>{currentCard.exampleSentence}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        playKoreanAudio(currentCard.exampleSentence);
                      }}
                      className="p-1 text-slate-400 hover:text-indigo-600"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {currentCard.exampleTranslation}
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Card Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100 text-xs text-slate-400">
              <span className="flex items-center gap-1">
                Kategoriya: <strong className="text-slate-600 capitalize">{currentCard.category}</strong>
              </span>
              <span>Ag'darish: Bosish orqali</span>
            </div>
          </div>

          {/* Navigation & Action Controls */}
          <div className="flex items-center justify-between gap-4 mt-6">
            <button
              onClick={handlePrev}
              className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Oldingisi
            </button>

            <button
              onClick={markKnown}
              className={`px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs ${
                isCurrentKnown
                  ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                  : 'bg-emerald-600 text-white hover:bg-emerald-700'
              }`}
            >
              <Check className="w-4 h-4" />
              {isCurrentKnown ? 'Yodlangan ✓' : 'Yodlab bo\'ldim (+10 XP)'}
            </button>

            <button
              onClick={handleNext}
              className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              Keyingisi
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
