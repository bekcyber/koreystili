import React, { useState } from 'react';
import { ShieldCheck, BookOpen, Clock, ChevronDown, ChevronUp, FileText, CheckCircle } from 'lucide-react';

export const TopikGuide: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: "EPS-TOPIK imtihoni nima va u kimlar uchun kerak?",
      a: "EPS-TOPIK (Employment Permit System - Test of Proficiency in Korean) — Janubiy Koreyada qonuniy ravishda ishchi viza (E-9) bilan ishlab chiqarish, qishloq xo'jaligi, qurilish va xizmat ko'rsatish sohalarida ishlashni xohlovchi fuqarolar uchun majburiy til imtihoni hisoblanadi."
    },
    {
      q: "EPS-TOPIK imtihoni qanday formatda o'tkaziladi?",
      a: "Imtihon kompyuterda (CBT) topshiriladi. Jami 40 ta savol: 20 ta o'qish (읽기 - Ilkki) va 20 ta tinglash (듣기 - Dutki). Har bir to'g'ri javob 5 balldan, maksimal 200 ball. Vaqt: 50 daqiqa."
    },
    {
      q: "TOPIK I va TOPIK II darajalari nimasi bilan farq qiladi?",
      a: "TOPIK (Test of Proficiency in Korean) — asosan Koreya universitetlariga o'qishga kirish (D-2 viza) yoki professional kompaniyalarga ishga kirish uchun kerak. TOPIK I (1-2 daraja, boshlang'ich), TOPIK II (3-6 daraja, o'rta va yuqori akademik daraja)."
    },
    {
      q: "Koreys tilini 0 dan boshlab qancha vaqtda o'rganish mumkin?",
      a: "Hangul alifbosi va o'qish qoidalarini 1-3 kunda o'rganish mumkin. EPS-TOPIK yoki TOPIK 1-2 darajaga yetishish uchun kuniga 2-3 soat muntazam shug'ullanish bilan 3 oydan 6 oygacha vaqt talab etiladi."
    },
    {
      q: "Imtihonga tayyorgarlikda nimalarga eng ko'p e'tibor qaratish kerak?",
      a: "1. Ish joyi asboblari va xavfsizlik terminologiyasi. 2. Tinglab tushunish (listening) ko'nikmasi. 3. Sin-koreys va sof koreys sonlarini farqlash. 4. Belgilar va yo'l xaritalari (rasmli savollar)."
    }
  ];

  return (
    <section className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-700 tracking-wide uppercase mb-2">
            <span>Rasmiy Imtihon Qo'llanmasi</span>
            <span aria-hidden="true">·</span>
            <span>시험 안내</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            TOPIK va EPS-TOPIK Imtihon Qo'llanmasi
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Janubiy Koreyada o'qish va qonuniy ishlash uchun zarur bo'lgan barcha ma'lumotlar, imtihon tuzilishi va maslahatlar.
          </p>
        </div>

        {/* 2 Big Cards: TOPIK vs EPS-TOPIK */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          
          {/* Card 1: EPS-TOPIK (Ishchi viza) */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider bg-indigo-50 px-2.5 py-1 rounded">
                  E-9 Ishchi Viza
                </span>
                <span className="text-xs text-slate-500 font-medium">50 daqiqa / 200 ball</span>
              </div>

              <h3 className="text-xl font-bold text-slate-900 mb-2">
                EPS-TOPIK Maxsus Imtihoni
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
                Tashqi Mehnat Migratsiyasi Agentligi orqali Janubiy Koreya zavod va korxonalarida ishlash uchun topshiriladigan test.
              </p>

              <div className="space-y-3 mb-6">
                <div className="flex items-start gap-2.5 text-xs text-slate-700">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div><strong>O'qish (읽기):</strong> 20 ta savol (zavod belgilari, xavfsizlik, grammatika)</div>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-700">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div><strong>Tinglash (듣기):</strong> 20 ta savol (boshliq buyruqlari, suhbatlar, sonlar)</div>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-700">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div><strong>O'tish bali:</strong> Soha bo'yicha odatda 110 - 150 ball oralig'ida</div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 text-xs text-slate-500">
              * Koreys tili 60 darslik rasmiy kitobi (한국어 표준교재) asosida o'tkaziladi.
            </div>
          </div>

          {/* Card 2: TOPIK Akademik (Talabalar uchun) */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider bg-emerald-50 px-2.5 py-1 rounded">
                  D-2 / D-4 Talaba Viza
                </span>
                <span className="text-xs text-slate-500 font-medium">1-6 Darajalar</span>
              </div>

              <h3 className="text-xl font-bold text-slate-900 mb-2">
                TOPIK I & TOPIK II (Akademik)
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
                Janubiy Koreya nufuzli universitetlariga grant (GKS) asosida yoki kontraktga qabul qilinish uchun talab etiladi.
              </p>

              <div className="space-y-3 mb-6">
                <div className="flex items-start gap-2.5 text-xs text-slate-700">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div><strong>TOPIK I (1-2 daraja):</strong> Tinglash (30 ta) + O'qish (40 ta), 200 ball</div>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-700">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div><strong>TOPIK II (3-6 daraja):</strong> Tinglash + Yozish (Insho) + O'qish, 300 ball</div>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-700">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div><strong>Grant uchun:</strong> Kamida TOPIK 3 yoki 4 daraja talab qilinadi</div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 text-xs text-slate-500">
              * NIFE (Koreya Ta'lim Vazirligi) tomonidan yiliga 6 marta o'tkaziladi.
            </div>
          </div>

        </div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl mx-auto">
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">
            Tez-Tez Beriladigan Savollar
          </h3>

          <div className="space-y-3">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden transition-all"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full p-4 text-left font-semibold text-slate-900 text-xs sm:text-sm flex items-center justify-between gap-4 hover:bg-slate-100 transition-colors"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-slate-500 shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                    )}
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-200/50 bg-white">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
