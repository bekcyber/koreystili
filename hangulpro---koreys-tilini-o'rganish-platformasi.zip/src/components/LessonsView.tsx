import React, { useState } from 'react';
import { LESSONS } from '../data/lessonsData';
import { Lesson } from '../types';
import { Volume2, CheckCircle2, Clock, BookOpen, ArrowRight, Award } from 'lucide-react';
import { playKoreanAudio, playSoundEffect } from '../utils/audio';

interface LessonsViewProps {
  onCompleteLesson: (lessonId: number) => void;
  completedLessons: number[];
}

export const LessonsView: React.FC<LessonsViewProps> = ({
  onCompleteLesson,
  completedLessons
}) => {
  const [selectedLessonId, setSelectedLessonId] = useState<number>(1);
  const currentLesson: Lesson = LESSONS.find(l => l.id === selectedLessonId) || LESSONS[0];

  const isCompleted = completedLessons.includes(currentLesson.id);

  const handleFinishLesson = () => {
    onCompleteLesson(currentLesson.id);
    playSoundEffect('level_up');
  };

  return (
    <section className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-700 tracking-wide uppercase mb-2">
            <span>Bosqichma-bosqich Darslik</span>
            <span aria-hidden="true">·</span>
            <span>한국어 수업</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Noldan Boshlab Koreys Tili Darslari
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Har bir dars audio dialoglar, grammatik qoidalar va so'z boyligini o'z ichiga oladi.
          </p>
        </div>

        {/* 2-Column Split: Lessons List Navigation + Active Lesson Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Lesson Selector */}
          <div className="lg:col-span-4 space-y-3">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
              Darslar Ro'yxati:
            </div>
            {LESSONS.map((lesson) => {
              const active = lesson.id === currentLesson.id;
              const done = completedLessons.includes(lesson.id);

              return (
                <button
                  key={lesson.id}
                  onClick={() => setSelectedLessonId(lesson.id)}
                  className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3.5 ${
                    active
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-sm'
                      : 'border-slate-200 bg-white hover:border-indigo-200 hover:bg-slate-50'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 ${
                    done
                      ? 'bg-emerald-100 text-emerald-700'
                      : active
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-600'
                  }`}>
                    {done ? '✓' : lesson.id}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-0.5">
                      <span>{lesson.level}</span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {lesson.estimatedMinutes} daq
                      </span>
                    </div>
                    <div className="text-sm font-semibold text-slate-900 truncate">
                      {lesson.title}
                    </div>
                    <div className="text-xs text-indigo-600 font-medium">
                      {lesson.koreanTitle}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Column: Detailed Lesson Content */}
          <div className="lg:col-span-8 bg-slate-50/70 border border-slate-200 rounded-2xl p-6 sm:p-8">
            
            {/* Lesson Title Banner */}
            <div className="border-b border-slate-200 pb-6 mb-6">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
                <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-1 rounded-md">
                  Dars {currentLesson.id}: {currentLesson.level}
                </span>
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  Davomiyligi: ~{currentLesson.estimatedMinutes} daqiqa
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mb-1">
                {currentLesson.title}
              </h3>
              <p className="text-sm text-slate-600">
                {currentLesson.description}
              </p>
            </div>

            {/* Dialogue Section */}
            {currentLesson.dialogue && currentLesson.dialogue.length > 0 && (
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-indigo-600" />
                    Namunaviy Suhbat va Dialog
                  </h4>
                  <span className="text-xs text-indigo-600">Audio tinglash uchun bosing</span>
                </div>

                <div className="space-y-3">
                  {currentLesson.dialogue.map((line, idx) => (
                    <div
                      key={idx}
                      className="bg-white p-4 rounded-xl border border-slate-200 flex items-start justify-between gap-4 shadow-2xs hover:border-indigo-200 transition-colors"
                    >
                      <div className="space-y-1">
                        <div className="text-xs font-bold text-indigo-600">
                          {line.speaker}
                        </div>
                        <div className="text-base font-semibold text-slate-900">
                          {line.korean}
                        </div>
                        <div className="text-xs text-slate-400 font-mono">
                          [{line.romanization}]
                        </div>
                        <div className="text-xs sm:text-sm text-slate-600 pt-0.5">
                          {line.uzbek}
                        </div>
                      </div>

                      <button
                        onClick={() => playKoreanAudio(line.korean)}
                        className="p-2.5 rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-colors shrink-0"
                        title="Tinglash"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Grammar Section */}
            <div className="mb-8">
              <h4 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                Grammatik Qoidalar va Qoliplar
              </h4>

              <div className="space-y-4">
                {currentLesson.grammar.map((point, gIdx) => (
                  <div key={gIdx} className="bg-white p-5 rounded-xl border border-slate-200">
                    <div className="text-sm font-bold text-slate-900 mb-1">
                      {point.title}
                    </div>
                    <div className="inline-block text-xs font-mono bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-semibold mb-2">
                      Qoida: {point.rule}
                    </div>
                    <p className="text-xs sm:text-sm text-slate-600 mb-4 leading-relaxed">
                      {point.explanation}
                    </p>

                    <div className="space-y-2 pt-2 border-t border-slate-100">
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Namunaviy gaplar:
                      </div>
                      {point.examples.map((eg, egIdx) => (
                        <div key={egIdx} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 text-xs">
                          <div>
                            <span className="font-bold text-slate-900 mr-2">{eg.korean}</span>
                            <span className="text-slate-400 font-mono text-[11px] mr-2">[{eg.romanization}]</span>
                            <span className="text-slate-600">{eg.uzbek}</span>
                          </div>
                          <button
                            onClick={() => playKoreanAudio(eg.korean)}
                            className="p-1 text-slate-400 hover:text-indigo-600"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Vocabulary for this lesson */}
            <div className="mb-8">
              <h4 className="text-sm font-bold text-slate-900 mb-3">
                Ushbu Darsning Asosiy So'zlari
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {currentLesson.vocabulary.map((vocab, vIdx) => (
                  <div
                    key={vIdx}
                    className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-slate-900 text-sm">{vocab.korean}</div>
                      <div className="text-slate-400 font-mono text-[11px]">[{vocab.romanization}]</div>
                      <div className="text-slate-600 mt-0.5">{vocab.uzbek}</div>
                    </div>
                    <button
                      onClick={() => playKoreanAudio(vocab.korean)}
                      className="p-2 text-slate-400 hover:text-indigo-600 rounded-lg"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Tips and Completion */}
            <div className="bg-amber-50/70 border border-amber-200 p-4 rounded-xl mb-6 text-xs text-amber-900">
              <div className="font-bold mb-1">💡 Foydali eslatma:</div>
              <ul className="list-disc list-inside space-y-1">
                {currentLesson.tips.map((tip, tIdx) => (
                  <li key={tIdx}>{tip}</li>
                ))}
              </ul>
            </div>

            {/* Finish Lesson Action */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-200">
              <div className="text-xs text-slate-500">
                {isCompleted ? (
                  <span className="text-emerald-600 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> Ushbu dars muvaffaqiyatli yakunlangan!
                  </span>
                ) : (
                  <span>Darsni to'liq o'qib bo'lgach, yakunlash tugmasini bosing (+50 XP)</span>
                )}
              </div>

              <button
                onClick={handleFinishLesson}
                className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
                  isCompleted
                    ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm'
                }`}
              >
                <Award className="w-4 h-4" />
                {isCompleted ? 'Qayta Yakunlash' : 'Darsni Yakunlash (+50 XP)'}
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
