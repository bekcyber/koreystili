import React from 'react';
import { ActiveTab } from '../types';
import { Volume2, BookOpen, GraduationCap, CheckCircle } from 'lucide-react';
import { playKoreanAudio } from '../utils/audio';

interface HeroProps {
  setActiveTab: (tab: ActiveTab) => void;
}

export const Hero: React.FC<HeroProps> = ({ setActiveTab }) => {
  return (
    <section className="relative overflow-hidden bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        
        {/* Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Headline and CTAs */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-xs font-semibold text-indigo-700 tracking-wide uppercase mb-3">
              <span>Noldan TOPIK Darajasigacha</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>O'zbek Tilida</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>Audio Talaffuz</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight text-balance mb-5">
              Koreys tilini oson, tez va <span className="text-indigo-600">mukammal</span> o'rganing
            </h1>

            <p className="text-base sm:text-lg text-slate-600 mb-8 max-w-xl leading-relaxed">
              Hangul alifbosini bir kunda o'rganing, audio talaffuzlar bilan so'z boyligingizni oshiring, 
              va Janubiy Koreyada o'qish (TOPIK) yoki ishlash (EPS-TOPIK E-9) imtihonlariga tayyorlaning.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 mb-8">
              <button
                onClick={() => setActiveTab('hangul')}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-sm flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                Alifbodan Boshlash (한글)
              </button>

              <button
                onClick={() => setActiveTab('lessons')}
                className="px-6 py-3.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center gap-2"
              >
                <GraduationCap className="w-4 h-4 text-slate-600" />
                Darslar Rejasi
              </button>

              <button
                onClick={() => playKoreanAudio('안녕하세요! 한국어 공부를 시작해 볼까요?')}
                className="px-4 py-3.5 text-xs font-medium text-slate-600 hover:text-indigo-600 border border-slate-200 rounded-xl transition-colors flex items-center gap-2"
                title="Namunaviy koreyscha gapni eshitish"
              >
                <Volume2 className="w-4 h-4 text-indigo-500" />
                <span>Ovozli Namuna</span>
              </button>
            </div>

            {/* Checklist highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>40 ta unli va undosh harf audio bilan</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Batchim (pastki harflar) sirlari</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Interaktiv bo'g'in yig'ish konstruktori</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>EPS-TOPIK zavod va ishchi lug'ati</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Asset */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-lg border border-slate-200 bg-slate-100">
              <img
                src="/src/assets/images/korean_learning_hero_1793133393371.jpg"
                alt="Koreys tilini o'rganish sinfi va Hangul ta'limi"
                className="w-full h-auto object-cover aspect-video sm:aspect-4/3 lg:aspect-auto"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent flex items-end p-6">
                <div className="text-white">
                  <div className="text-xs uppercase tracking-wider text-indigo-300 font-semibold mb-1">
                    Interaktiv Ta'lim
                  </div>
                  <div className="text-lg font-bold">
                    한글 배우기 · Hangul O'rganish
                  </div>
                  <div className="text-xs text-slate-200 mt-0.5">
                    Talaffuz, grammatika va testlar bitta qulay platformada
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Proof of Metrics Strip */}
        <div className="mt-12 pt-8 border-t border-slate-200 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">40 ta</div>
            <div className="text-xs text-slate-500 mt-1">Harf va Qoidalar</div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">6 ta</div>
            <div className="text-xs text-slate-500 mt-1">Bosqichli Dars</div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">100+</div>
            <div className="text-xs text-slate-500 mt-1">Muhim So'z va Iboralar</div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-indigo-600 tabular-nums">100% Bepul</div>
            <div className="text-xs text-slate-500 mt-1">O'zbek Tilida</div>
          </div>
        </div>

      </div>
    </section>
  );
};
