import React from 'react';
import { ActiveTab } from '../types';
import { Volume2, Sparkles } from 'lucide-react';
import { playKoreanAudio } from '../utils/audio';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  userXp: number;
  streakDays: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  userXp,
  streakDays
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Single clean text element wordmark */}
        <button
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 text-left focus:outline-none shrink-0"
          aria-label="HangulPro bosh sahifasiga qaytish"
        >
          <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-lg shadow-sm">
            한
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap">
            HangulPro
          </span>
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setActiveTab('hangul')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'hangul'
                ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900'
            }`}
          >
            Alifbo (한글)
          </button>
          <button
            onClick={() => setActiveTab('lessons')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'lessons'
                ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900'
            }`}
          >
            Darslar
          </button>
          <button
            onClick={() => setActiveTab('flashcards')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'flashcards'
                ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900'
            }`}
          >
            Lug'at & Kartochkalar
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'quiz'
                ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900'
            }`}
          >
            Test Sinovi
          </button>
          <button
            onClick={() => setActiveTab('topik')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'topik'
                ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900'
            }`}
          >
            EPS-TOPIK
          </button>
        </nav>

        {/* Zone 3: XP counter & 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span className="tabular-nums font-semibold text-slate-900">{userXp}</span> XP
            <span className="text-slate-300">|</span>
            <span className="text-emerald-700 font-medium">🔥 {streakDays} kun</span>
          </div>

          <button
            onClick={() => {
              playKoreanAudio('안녕하세요');
            }}
            title="Audio talaffuzni sinab ko'rish"
            aria-label="Audio talaffuzni sinash"
            className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <Volume2 className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab('lessons')}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors whitespace-nowrap shadow-sm"
          >
            O'rganishni Boshlash
          </button>
        </div>
      </div>

      {/* Mobile nav bar */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-100 py-2 px-2 bg-slate-50 text-xs font-medium text-slate-600">
        <button
          onClick={() => setActiveTab('hangul')}
          className={`px-2 py-1 rounded ${activeTab === 'hangul' ? 'text-indigo-600 font-bold bg-white' : ''}`}
        >
          Alifbo
        </button>
        <button
          onClick={() => setActiveTab('lessons')}
          className={`px-2 py-1 rounded ${activeTab === 'lessons' ? 'text-indigo-600 font-bold bg-white' : ''}`}
        >
          Darslar
        </button>
        <button
          onClick={() => setActiveTab('flashcards')}
          className={`px-2 py-1 rounded ${activeTab === 'flashcards' ? 'text-indigo-600 font-bold bg-white' : ''}`}
        >
          Lug'at
        </button>
        <button
          onClick={() => setActiveTab('quiz')}
          className={`px-2 py-1 rounded ${activeTab === 'quiz' ? 'text-indigo-600 font-bold bg-white' : ''}`}
        >
          Test
        </button>
        <button
          onClick={() => setActiveTab('topik')}
          className={`px-2 py-1 rounded ${activeTab === 'topik' ? 'text-indigo-600 font-bold bg-white' : ''}`}
        >
          EPS-TOPIK
        </button>
      </div>
    </header>
  );
};
