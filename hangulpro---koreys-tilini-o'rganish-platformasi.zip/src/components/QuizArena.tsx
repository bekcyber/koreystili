import React, { useState } from 'react';
import { QUIZ_QUESTIONS } from '../data/quizData';
import { QuizQuestion } from '../types';
import { Volume2, CheckCircle2, XCircle, RotateCcw, Award, ArrowRight } from 'lucide-react';
import { playKoreanAudio, playSoundEffect } from '../utils/audio';
import { calculateQuizResult } from '../utils/hangul';

interface QuizArenaProps {
  onCompleteQuiz: (xpEarned: number) => void;
}

export const QuizArena: React.FC<QuizArenaProps> = ({ onCompleteQuiz }) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  const question: QuizQuestion = QUIZ_QUESTIONS[currentIdx] || QUIZ_QUESTIONS[0];

  const handleSelectOption = (index: number) => {
    if (isAnswerSubmitted) return;
    setSelectedAnswer(index);
    setIsAnswerSubmitted(true);

    if (index === question.correctAnswer) {
      setCorrectCount(prev => prev + 1);
      playSoundEffect('correct');
    } else {
      playSoundEffect('wrong');
    }
  };

  const handleNextQuestion = () => {
    if (currentIdx + 1 < QUIZ_QUESTIONS.length) {
      setCurrentIdx(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswerSubmitted(false);
    } else {
      const result = calculateQuizResult(correctCount + (selectedAnswer === question.correctAnswer ? 0 : 0), QUIZ_QUESTIONS.length);
      onCompleteQuiz(result.xp);
      setQuizFinished(true);
      playSoundEffect('level_up');
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);
    setCorrectCount(0);
    setQuizFinished(false);
  };

  const result = calculateQuizResult(correctCount, QUIZ_QUESTIONS.length);

  return (
    <section className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-700 tracking-wide uppercase mb-2">
            <span>Bilimni Sinash Arenasi</span>
            <span aria-hidden="true">·</span>
            <span>한국어 퀴즈</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Koreys Tili Interaktiv Testi
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Alifbo, so'zlar, grammatika va audio tinglash bo'yicha bilimlaringizni sinab ko'ring.
          </p>
        </div>

        {!quizFinished ? (
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs">
            
            {/* Top Bar: Progress & Question info */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
              <span className="text-xs font-semibold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded">
                Savol {currentIdx + 1} / {QUIZ_QUESTIONS.length}
              </span>

              <div className="text-xs font-medium text-slate-600">
                To'g'ri javoblar: <span className="text-emerald-600 font-bold tabular-nums">{correctCount}</span>
              </div>
            </div>

            {/* Question Text */}
            <div className="mb-6">
              <h3 className="text-base sm:text-lg font-bold text-slate-900 mb-3">
                {question.prompt}
              </h3>

              {question.koreanText && (
                <div className="p-4 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-4">
                  <div className="text-xl sm:text-2xl font-extrabold text-indigo-950 font-sans">
                    {question.koreanText}
                  </div>
                  <button
                    onClick={() => playKoreanAudio(question.koreanText || '')}
                    className="p-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-lg transition-colors shrink-0"
                    title="Audio eshitish"
                  >
                    <Volume2 className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>

            {/* Answer Options */}
            <div className="space-y-3 mb-6">
              {question.options.map((opt, idx) => {
                const isSelected = selectedAnswer === idx;
                const isCorrect = idx === question.correctAnswer;

                let btnStyle = 'border-slate-200 bg-white hover:border-indigo-300 hover:bg-slate-100/50 text-slate-800';

                if (isAnswerSubmitted) {
                  if (isCorrect) {
                    btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-semibold ring-1 ring-emerald-500';
                  } else if (isSelected) {
                    btnStyle = 'border-rose-500 bg-rose-50 text-rose-900 font-semibold ring-1 ring-rose-500';
                  } else {
                    btnStyle = 'border-slate-200 bg-white opacity-60 text-slate-500';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswerSubmitted}
                    onClick={() => handleSelectOption(idx)}
                    className={`w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between text-xs sm:text-sm ${btnStyle}`}
                  >
                    <span>{opt}</span>
                    {isAnswerSubmitted && isCorrect && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    )}
                    {isAnswerSubmitted && isSelected && !isCorrect && (
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation box after submission */}
            {isAnswerSubmitted && (
              <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-100 mb-6 text-xs text-indigo-950">
                <div className="font-bold mb-1">Izoh va Tushuntirish:</div>
                <p className="leading-relaxed">{question.explanation}</p>
              </div>
            )}

            {/* Action Bottom */}
            {isAnswerSubmitted && (
              <div className="flex justify-end pt-2">
                <button
                  onClick={handleNextQuestion}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors shadow-sm"
                >
                  <span>{currentIdx + 1 === QUIZ_QUESTIONS.length ? 'Natijalarni Ko\'rish' : 'Keyingi Savol'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}

          </div>
        ) : (
          /* Quiz Results Card */
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-8 text-center max-w-lg mx-auto shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-indigo-100 text-indigo-600 mx-auto flex items-center justify-center mb-4">
              <Award className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-bold text-slate-900 mb-1">
              Test Muvaffaqiyatli Yakunlandi!
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Siz koreys tili bo'yicha bilimlaringizni sinab ko'rdingiz.
            </p>

            <div className="grid grid-cols-3 gap-3 bg-white p-4 rounded-xl border border-slate-200 mb-6 text-center">
              <div>
                <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
                  {correctCount} / {QUIZ_QUESTIONS.length}
                </div>
                <div className="text-[11px] text-slate-400">To'g'ri javob</div>
              </div>

              <div>
                <div className="text-2xl font-extrabold text-indigo-600 tabular-nums">
                  {result.percentage}%
                </div>
                <div className="text-[11px] text-slate-400">Aniqlik darajasi</div>
              </div>

              <div>
                <div className="text-2xl font-extrabold text-amber-600 tabular-nums">
                  +{result.xp}
                </div>
                <div className="text-[11px] text-slate-400">XP Ball</div>
              </div>
            </div>

            <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl text-xs font-semibold text-indigo-900 mb-6">
              Baholash darajangiz: {result.rank}
            </div>

            <button
              onClick={handleRestart}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold inline-flex items-center gap-2 transition-colors shadow-sm"
            >
              <RotateCcw className="w-4 h-4" />
              Testni Qaytadan Boshlash
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
