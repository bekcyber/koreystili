import React from 'react';
import { ActiveTab } from '../types';

interface FooterProps {
  setActiveTab: (tab: ActiveTab) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          
          {/* Brand info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm">
                한
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                HangulPro
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 max-w-sm leading-relaxed">
              O'zbekiston yoshlari, talabalar va Koreyada ishlash istagidagi yurtdoshlarimiz uchun qulay, bepul va zamonaviy koreys tili ta'lim platformasi.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-200 mb-3">
              Bo'limlar
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => setActiveTab('hangul')}
                  className="hover:text-white transition-colors"
                >
                  Koreys Alifbosi (Hangul)
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('lessons')}
                  className="hover:text-white transition-colors"
                >
                  Bosqichli Darslar
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('flashcards')}
                  className="hover:text-white transition-colors"
                >
                  Interaktiv Lug'at
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('quiz')}
                  className="hover:text-white transition-colors"
                >
                  Test Sinovi
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('topik')}
                  className="hover:text-white transition-colors"
                >
                  EPS-TOPIK Qo'llanmasi
                </button>
              </li>
            </ul>
          </div>

          {/* Cultural Tip */}
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-200 mb-3">
              Foydali Ma'lumot
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Hangul (한글) 1443-yilda yaratilgan bo'lib, YUNESKO Jahon Merosi ro'yxatiga kiritilgan dunyodagi eng ilmiy va mantiqiy alifbolardan biridir.
            </p>
          </div>

        </div>

        {/* Bottom copyright line */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div>
            © {new Date().getFullYear()} HangulPro. Barcha huquqlar himoyalangan.
          </div>
          <div className="flex items-center gap-4">
            <span>O'zbek tilidagi bepul ta'lim loyihasi</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
