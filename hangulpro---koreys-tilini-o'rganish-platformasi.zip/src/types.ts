export type LetterType = 'basic_vowel' | 'complex_vowel' | 'basic_consonant' | 'double_consonant' | 'batchim';

export interface HangulLetter {
  id: string;
  char: string;
  name: string;
  type: LetterType;
  uzbekSound: string;
  romanization: string;
  description: string;
  exampleWord: string;
  exampleTranslation: string;
  examplePronunciation: string;
}

export interface BatchimRule {
  representativeSound: string;
  letters: string[];
  uzbekExplanation: string;
  examples: {
    word: string;
    reading: string;
    meaning: string;
  }[];
}

export interface LessonDialogLine {
  speaker: string;
  korean: string;
  romanization: string;
  uzbek: string;
}

export interface GrammarPoint {
  title: string;
  rule: string;
  explanation: string;
  examples: {
    korean: string;
    romanization: string;
    uzbek: string;
  }[];
}

export interface Lesson {
  id: number;
  level: string;
  title: string;
  koreanTitle: string;
  description: string;
  estimatedMinutes: number;
  objectives: string[];
  dialogue?: LessonDialogLine[];
  grammar: GrammarPoint[];
  vocabulary: {
    korean: string;
    romanization: string;
    uzbek: string;
  }[];
  tips: string[];
}

export interface Flashcard {
  id: string;
  korean: string;
  romanization: string;
  uzbek: string;
  category: 'greeting' | 'food' | 'numbers' | 'travel' | 'work_eps' | 'daily';
  exampleSentence: string;
  exampleTranslation: string;
}

export interface QuizQuestion {
  id: number;
  type: 'meaning' | 'listening' | 'grammar' | 'hangul';
  prompt: string;
  koreanText?: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export type ActiveTab = 'home' | 'hangul' | 'lessons' | 'flashcards' | 'quiz' | 'topik';
